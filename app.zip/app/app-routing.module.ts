import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuardGuard } from './guards/auth-guard.guard';

const routes: Routes = [
  {
    path: 'aw',
    canActivate: [AuthGuardGuard],
    canLoad: [AuthGuardGuard],
    loadChildren: () => import('./layouts/common-layout/common-layout.module').then(m => m.CommonLayoutPageModule)
  },
  {
    path: 'aw-login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: '',
    redirectTo: 'aw/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'user-menu',
    loadChildren: () => import('./pages/user-menu/user-menu.module').then( m => m.UserMenuPageModule)
  },
  {
    path: 'account-settings',
    loadChildren: () => import('./pages/account-settings/account-settings.module').then( m => m.AccountSettingsPageModule)
  },
  {
    path: 'notifications-page',
    loadChildren: () => import('./pages/notifications-page/notifications-page.module').then( m => m.NotificationsPagePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
