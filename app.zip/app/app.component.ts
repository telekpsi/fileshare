import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, Subject, takeUntil } from 'rxjs';

import { isLoggedIn } from './store/app-selectors';
import { AppState, UserLoggedOut } from './store/app-store';
import { Darkmode } from './store/settings-selectors';
import { InitializedAppData, SettingsState, setDeviceDarkmode } from './store/settings-store';
import { StatusBar } from '@capacitor/status-bar';
import { Platform } from '@ionic/angular';
import { StorageService } from './services/ionic-storage.service';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
  private readonly destroyed$ = new Subject()
  submenu = false;
  loggedIn$: Observable<boolean>;
  primary: string = '';
  // primary: string = getComputedStyle(document.documentElement).getPropertyValue('--ion-color-primary').toString();

  current_tab = "dashboard";
  public appPages = [
    { title: 'Home', url: '/dashboard', icon: 'home', tab: 'dashboard' },
    { title: 'Accounts', url: '/accounts', icon: 'wallet', tab: 'accounts' },
    { title: 'Documents', url: '/documents', icon: 'document-text', tab: 'documents' },
    { title: 'Financial Prof.', url: '/advisors', icon: 'people', tab: 'advisors' },
  ];

  constructor(private store: Store<AppState & SettingsState>, private platform: Platform, private storage: StorageService) {
    this.loggedIn$ = this.store.select(isLoggedIn);
    // this.initializeApp();
  }

  // initializeApp() {
  //   this.platform.ready().then(() => {
  //   });
  // }

  ngOnInit() {
    // darkmode controls
    this.storage.initialize();
    this.store.dispatch(InitializedAppData());
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener("change",
      (mediaQuery) => {
        this.store.dispatch(setDeviceDarkmode({darkmode: mediaQuery.matches}))
      }
    );
    this.store.select(Darkmode).pipe(takeUntil(this.destroyed$)).subscribe( darkmode => {
      document.body.classList.toggle('dark', darkmode);
    });  
  }

  onLogout() {
    this.store.dispatch(UserLoggedOut());
  }

  setCurrentTab(event: any) {
    this.current_tab = event.tab;
  }
}
