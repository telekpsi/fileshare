import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";
import { switchMap, mergeAll, EMPTY, Observable } from "rxjs";
import { DeviceService } from "src/app/services/device.service";
import { InitializedAppData, loadedDarkmode, loadedSavedCredentials, setDeviceDarkmode, willSaveCredentials } from "src/app/store/settings-store";


@Injectable()
export class AppEffects {

    constructor(
        private actions$: Actions,
        private deviceService: DeviceService,
    ) { }
    
    nothingSet(): Observable<never> {
        this.deviceService.setDarkmode('device');
        return EMPTY;
    }


    InitializedAppData$ = createEffect(() => this.actions$.pipe(
        ofType(InitializedAppData),
        switchMap(async (action) => {
            let initializedData: Action[] = [];
            await this.deviceService.loadCredentials().then(values => 
                initializedData.push(loadedSavedCredentials({username: values[0], password: values[1]})));
            await this.deviceService.getDarkmode().then(value =>
                !!value ? initializedData.push(loadedDarkmode({darkmode: value})) : this.nothingSet());
            await this.deviceService.getLocalSetting('saveCredentials').then(value => 
                initializedData.push(willSaveCredentials({saveCredentials: !!value})));
            const deviceDarkmode = window.matchMedia('(prefers-color-scheme: dark)');
                initializedData.push(setDeviceDarkmode({darkmode: deviceDarkmode.matches}));
            return (initializedData);
        }),
        mergeAll(),
        )
    )

}