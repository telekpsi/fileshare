import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from './services/ionic-storage.service'

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { appStateReducer } from './store/app-store';
import { LoginEffects } from './pages/login/login.effects';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from './shared/shared.module';
import { settingsStateReducer } from './store/settings-store';
import { AppEffects } from './app.effects';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    SharedModule,
    IonicModule.forRoot(),
    IonicStorageModule.forRoot(),
    AppRoutingModule,
    StoreModule.forRoot({ app: appStateReducer, settings: settingsStateReducer }),
    EffectsModule.forRoot([AppEffects, LoginEffects]),
    HttpClientModule,
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule { }
