import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Store } from '@ngrx/store';
import { isEmpty, map, Observable, tap, withLatestFrom } from 'rxjs';
import { AppState } from '../store/app-store';
import { getClient, isLoggedIn } from '../store/app-selectors';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardGuard implements CanActivate, CanLoad {

  constructor(private store: Store<AppState>, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.isLoggedInCheck();
  }

  canLoad(route: Route, segments: UrlSegment[]):
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.isLoggedInCheck();
  }

  private isLoggedInCheck() {
    let hasClientData = this.store.select(getClient).pipe(isEmpty(),map(e => !e));
    return this.store.select(isLoggedIn).pipe(
      withLatestFrom(hasClientData),
      map(([auth, data]) => (auth && data)),
      tap(activate => activate ? '' : this.router.navigate(['/aw-login']))
    );
  }
}
