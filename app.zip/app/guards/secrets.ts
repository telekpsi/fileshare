export class Secrets {
    private static _rsaKey: string = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkwzoLULgMWSrLPk+naXs1GhAsxOiE8+J0shtnoeIC7nnwUAU8SHfQklYyqoitN6X0D9h55VfFlqzaAXEIgfGp3tL0OJOtioza3Yhdn2YWsfCSwXQNzqqjLmwagUZQOuYO2Y9sg30MG46EjfukT9wEsh3NdZqCu+XzY7gu0YMjhtfpajzgHtPpIZBq0h8WOm5N8rLDn+B/Jfcp3Oa4DrQYCcBaNdZ66cAEN08CRqatHzHoGW1DN+389YMTixfF5xfAIWe8Zne6MJTAYOQViUXYUAcGo6qqUBrebjaDzzgTu+juOVf6al6phMIMbO9LQSKM/tknYvjwBNwwcVev+jQeQIDAQAB";
    
    static get rsaKey(): string {
        return this._rsaKey;
    }
}
