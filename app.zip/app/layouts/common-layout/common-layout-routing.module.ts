import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommonLayoutPage } from './common-layout.page';

const routes: Routes = [
  {
    path: '', //aw
    component: CommonLayoutPage,
    children: [
      {
        path: 'documents',
        loadChildren: () => import('../../pages/documents/documents.module').then(m => m.DocumentsPageModule)
      },
      {
        path: 'accounts',
        loadChildren: () => import('../../pages/accounts/accounts.module').then(m => m.AccountsPageModule)
      },
      {
        path: 'dashboard',
        loadChildren: () => import('../../pages/dashboard/dashboard.module').then(m => m.DashboardPageModule)
      },
      {
        path: 'advisors',
        loadChildren: () => import('../../pages/advisors/advisors.module').then(m => m.AdvisorsPageModule)
      },
      {
        path: 'user-menu',
        loadChildren: () => import('../../pages/user-menu/user-menu.module').then(m => m.UserMenuPageModule)
      },
      {
        path: 'account-settings',
        loadChildren: () => import('../../pages/account-settings/account-settings.module').then(m => m.AccountSettingsPageModule)
      },
      {
        path: 'notifications',
        loadChildren: () => import('../../pages/notifications-page/notifications-page.module').then(m => m.NotificationsPagePageModule)
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommonLayoutPageRoutingModule { }
