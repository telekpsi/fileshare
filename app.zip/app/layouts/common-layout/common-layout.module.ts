import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SharedModule } from '../../shared/shared.module';
import { CommonLayoutPageRoutingModule } from './common-layout-routing.module';
import { CommonLayoutPage } from './common-layout.page';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    IonicModule,
    CommonLayoutPageRoutingModule
  ],
  declarations: [CommonLayoutPage]
})
export class CommonLayoutPageModule { }
