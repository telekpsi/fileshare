import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { EMPTY, Subject, takeUntil } from 'rxjs';

import { Client } from '../../models/index.models';
import { getClient } from '../../store/app-selectors';
import { AppState } from '../../store/app-store';
import { Router } from '@angular/router';

@Component({
  selector: 'app-common-layout',
  templateUrl: './common-layout.page.html',
  styleUrls: ['./common-layout.page.scss'],
})
export class CommonLayoutPage implements OnInit {
  private destroy$ = new Subject();
  client!: Client;

  current_tab = "dashboard";
  public appPages = [
    { title: 'Home', url: 'dashboard', icon: 'home', tab: 'dashboard' },
    { title: 'Accounts', url: 'accounts', icon: 'wallet', tab: 'accounts' },
    { title: 'Documents', url: 'documents', icon: 'document-text', tab: 'documents' },
    { title: 'Financial Prof.', url: 'advisors', icon: 'people', tab: 'advisors' },
  ];

  constructor(private store: Store<AppState>, protected menuCtrl: MenuController, private router: Router) {
    this.store.select(getClient).pipe(takeUntil(this.destroy$)).subscribe(c => this.client = c);
  }

  ngOnInit() {}

  ngOnDestroyed() {
    this.destroy$.next(EMPTY);
  }

  setCurrentTab(event: any) {
    this.current_tab = event.tab;
  }


}
