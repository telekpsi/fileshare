export type accountCategory = 'Investment' | 'Asset' | 'Liability' | 'External' | 'Authorized' | 'Unknown';
export type accountsDataStatus = 'Broken Yodlee Link'

export type Account = {
    accountCategory: accountCategory,
    accountId: string, // Cetera DB
    accountNumber?: string, // Non-manual, masked
    hasBrokenLink?: boolean,
    accountName: string,
    nickname?: string,
    accountCustodian?: string, // Owning party of account
    
    accountValue: number, // USD Value of account
    interest?: number, // Liability only
    
    lastUpdated?: string, // UTC string date
    // status: accountsDataStatus[],
    status: accountsDataStatus,

    ugl?: { // Unrealized Gain/Loss
        value: number; 
        percentage: number
    }
};

export type AccountsCategory = {
    accountCategory: accountCategory,
    totalAccountsValue: number,
    status?: boolean,
    ugl?: {
        value: number,
        percentage: number,
    },
    accounts: Account[],
}

// export type AccountCategoryInfo = {
//     accountCategory: accountCategory,
//     isInternal: boolean,
//     totalAccountsValue: number,
//     ugl?: {
//         value: number;
//         percentage: number;
//     },
//     title: string,
//     tooltip: string,
//     accounts: Account[],
// }