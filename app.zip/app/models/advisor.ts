import { Phone, MailingAddress } from "./common/index.common";

export type Advisor = {
  isPrimary: boolean;
  advisorId: number;
  name: {
    first: string;
    last: string;
    initials: string;
    full: string;
    preferred?: string;
  };
  pronouns?: string;
  phones: Phone[];
  email_primary: string;
  email_secondary?: string;
  mailingAddress: MailingAddress;
};

// export const MOCKADVISORS: Advisor[] = [
//   {
//     isPrimary: false,
//     advisorId: 1234567890,
//     name: {
//       first: "Jennifer",
//       last: "Davis",
//       initials: "JD",
//       full: "Jennifer Davis",
//     },
//     pronouns: 'she/her',
//     phones: [
//       { type: 'Work', number: 8586170300 },
//     ],
//     email_primary: "jennifer.davis@cefg.com",
//     mailingAddress: {
//       type: 'Office',
//       addressLine1: '123 Main Street',
//       addressLine2: 'Suite 100',
//       city: 'Anytown',
//       state: 'YSA',
//       zip: '12345'
//     }
//   },
//   {
//     isPrimary: true,
//     advisorId: 1234567891,
//     name: {
//       first: "Chris",
//       last: "Michael",
//       initials: "CM",
//       full: "Chris Michael",
//     },
//     pronouns: 'he/him',
//     phones: [
//       { type: 'Work', number: 8586170300 },
//     ],
//     email_primary: "chris.michael@cefg.com",
//     mailingAddress: {
//       type: 'Office',
//       addressLine1: '123 Main Street',
//       addressLine2: 'Suite 100',
//       city: 'Anytown',
//       state: 'YSA',
//       zip: '12345'
//     }
//   },
// ];

// export const MOCKADVISORSIDS: string[] = ['1234567890', '1234567891'];