export type AllocationData = {
    externalAssets: AllocationCategoryData[],
    internalAssets: AllocationCategoryData[],
    portfolioAssets: AllocationCategoryData[]
};

export type AllocationCategoryData = {
    allocationPercentage: number,
    value: number,
    amountLabel: string,
    assetColorCode: string,
    name: string
}