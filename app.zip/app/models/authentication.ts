import { otpMechanism } from "../services/models/security.model";

export type AuthenticationProfile = {
    sessionId: string,
    allowForgotPassword: boolean,
    passwordMechanismId: string,
    resetMechanismId?: string,
    otpMechanisms: otpMechanism[],
    success?: {
        authToken: string,
        userId: string,
    },
    // mechanisms: {
    //     mechId: string,
    //     type: password | otp | ssn,
    //     label?: string,
    // }
};