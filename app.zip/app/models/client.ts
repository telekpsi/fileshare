import { Phone, MailingAddress } from "./common/index.common";

export type Client = {
  clientId: string;
  lastLogin?: number;
  dob: Date;
  name: {
    first: string;
    last: string;
    initials: string;
    full: string;
    preferred?: string;
  }
  pronouns?: string;

  phones: Phone[];
  email_primary: string;
  email_secondary?: string;
  // mailingAddress: MailingAddress;
  mailingAddress: string;
};
export const MOCKCLIENT: Client = {
  clientId: "1234567890",
  lastLogin: Date.now(),
  dob: new Date('2/21/92'),
  name: {
    first: "James",
    last: "Wilson",
    initials: "JW",
    full: "James Wilson",
    preferred: "Jay"
  },
  pronouns: 'he/him',
  phones: [
    { type: 'Mobile', number: 1234567890 }, { type: 'Work', number: 56789012345 }
  ],
  email_primary: "James.Wilson@cfg.com",
  // mailingAddress: {
  //   type: 'Home',
  //   line1: '123 Main Street',
  //   line2: 'Suite 100',
  //   city: 'Anytown',
  //   state: 'YSA',
  //   zip: 12345
  // }
  mailingAddress: "13 Manor Ave<br> Claymont, DE 19703 <br>United States"
};