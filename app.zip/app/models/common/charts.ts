import { CurrencyPipe } from "@angular/common";

export type CategoryData = {
  name: string,
  value: number,
};

export const ALLOCATIONMOCKDATA: CategoryData[] = [
  {
    name: "cat1",
    value: 12.4
  },
  {
    name: "cat2",
    value: 2.3
  },
  {
    name: "cat3",
    value: 8.1
  },
  {
    name: "cat4",
    value: 17.9
  },
  {
    name: "cat5",
    value: 23.3
  },
  {
    name: "cat6",
    value: 11.0
  },
];

export type DateTimeSeries = {
  name: string;
  data: DateTimeData[];
}
export type DateTimeData = {
  date: string;
  value: number;
}

const UNIXDAY = 86400000;

export const MOCKNETWORTHDATA: DateTimeSeries[] = [
  {
    name: "Investment",
    data: generateMockData(),
  },
  {
    name: "Authorized",
    data: generateMockData(),
  },
  {
    name: "Linked",
    data: generateMockData(),
  },
  {
    name: "Manual",
    data: generateMockData(),
  },
]

function generateMockData (
  start: number = 10000, 
  growthRate: number = 0.65, 
  marketSpeed: number = (1/50), 
  days: number = 365, 
  pollRate: number = 0.65
  ): DateTimeData[] {
  let value = start;
  let date = Date.now()-(300*UNIXDAY);
  let data: {date: string, value: number}[] = [];
  for (let i=0; i<days; i++) {
    if (i==0) {
      data.push({date: toEchartsDate(date), value});
    } else {
      value *= (1 + ((growthRate-Math.random())*marketSpeed));
      date += UNIXDAY;

      const fixed = value.toFixed(2);
      const match = fixed.match(/\d{1,3}(?=(\d{3}))*(?=\.\d{2})$/g);
      const format = '$'+match?.join(',');

      if(Math.random()<=pollRate) {
        data.push({date: toEchartsDate(date), value});
      } else {
        data.push({date: toEchartsDate(date), value: data[data.length-1].value} );
      }
    }
  }
  return data;
}

function toEchartsDate(date: number): string {
  const dateObj = new Date(date)
  return `${dateObj.getFullYear()}-${dateObj.getMonth()}-${dateObj.getDate()}T${dateObj.getHours()}:${dateObj.getMinutes()}:${dateObj.getSeconds()+'.000'}Z`
  // '2018-04-10T20:40:33Z'
}