export type statusMessage = {
    title?: string,
    body: string,
    type: 'error' | 'warn' | 'info'
}