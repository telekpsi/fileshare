export type Phone = {
    type?: 'Mobile' | 'Home' | 'Work';
    number: number | string;
};