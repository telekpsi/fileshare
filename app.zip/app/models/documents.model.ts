export type BoxItem = {
    id: string,
    name: string,
    eTag?: any,
    data?: BoxItem[],
    createDate: any,
    updateDate: any,
    updatedBy: any,
    fileExtension?: string,
    size: number,
    rawSize: number,
    userType: string,
    isShared: boolean
    fpSharedCount: number,
    externalSharedCount: number,
    sharedWith?: string[],
    folder: boolean,
    parentFolder?: BoxItem,
}