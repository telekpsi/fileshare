export type Env = {
    production: boolean,
    API_ENDPOINT: string,
    SECURITY_API_ENDPOINT: string,
}