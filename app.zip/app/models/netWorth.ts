export type NetWorthHighlights = {
    ceteraAccountsCount: number,
    ceteraAccountsValue: number,
    ceteraMarketValue: number,
    hasBrokenLink: boolean,
    linkedAssetsCount: number,
    linkedAssetsValue: number,
    linkedLiabilitiesCount: number,
    linkedLiabilitiesValue: number,
    pershingAPIResponse: boolean
    totalNetAssets: number,
    totalNetCash: number,
    totalNetMarketValue: number,
    totalNetMoneyMarket: number,
    totalNetWorth: number
}