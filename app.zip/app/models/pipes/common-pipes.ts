import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'phone' })
export class PhoneNumber implements PipeTransform {
  formatPhoneNumber(s: any) {
    let cleaned = ("" + s).replace(/\D/g, '');
    let countryCode = cleaned.slice(0, cleaned.length - 10);
    let mainNumber = cleaned.substring(cleaned.length - 10);
    const m = mainNumber.match(/^(\d{3})(\d{3})(\d{4})$/);
    let noCountry = (!m) ? null : "(" + m[1] + ") " + m[2] + "-" + m[3];
    return (countryCode.length > 0) ? `+${countryCode} ${noCountry}` : noCountry;
  }
  formatPhoneNumberNoRegex(s: any) {
    let cleaned = ("" + s).replace(/\D/g, '');
    let countryCode = cleaned.slice(0, cleaned.length - 10);
    let mainNumber = cleaned.substring(cleaned.length - 10);
    let pArea = mainNumber.substring(0, 3);
    let pPrefix = mainNumber.substring(3, 6);
    let pLine = mainNumber.substring(6, 10);
    let noCountry = (mainNumber.length != 10) ? null : "(" + pArea + ") " + pPrefix + "-" + pLine;
    return (countryCode.length > 0) ? `+${countryCode} ${noCountry}` : noCountry;
  }
  transform(val: any) {
    let formattedPhone = "";
    try {
      formattedPhone = <string>this.formatPhoneNumber(val);

    } catch (error) {
      formattedPhone = val;
    }

    if (formattedPhone == null)
      formattedPhone = val;

    return formattedPhone;
  }
}

@Pipe({ name: 'maskPhoneNumber' })
export class PhoneMasker implements PipeTransform {
  transform(val: any) {
    let maskedVal = "";
    try {
      maskedVal = <string>val.substring(val.length-4);
      // maskedVal = "XXX XXX " + maskedVal;
    } catch (error) {
      console.log(error);
    }
    return maskedVal;
  }
}
@Pipe({ name: 'maskAccountNumber' })
export class Masker implements PipeTransform {
  mask(val: string) {
    if (val.length < 5) {
      return val;
    } else {
      return val.substring(val.length-4);
    }
  }
  transform(val: any) {
    let maskedVal = "";
    try {
      maskedVal = <string>this.mask(val);
    } catch (error) {
      maskedVal.length > 4 || maskedVal.length <= 0;
    }
    return maskedVal;
  }
}

@Pipe({ name: 'truncateAccountName' })
export class Truncator implements PipeTransform {
  truncate(val: string) {
    if (val.length < 17) {
      return val;
    } else {
      return (val.substring(0,15)+'...');
    }
  }
  transform(val: any) {
    let truncatedVal = "";
    try {
      truncatedVal = <string>this.truncate(val);
    } catch (error) {
      truncatedVal.length > 15 || truncatedVal.length <= 0;
    }
    return truncatedVal;
  }
}