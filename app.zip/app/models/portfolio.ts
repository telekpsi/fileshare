export const PORTFOLIOID: string = "a1b2c3";


export type Portfolio = {
  accountIds: string[];
  netWorthChangeAmount: number;
  netWorthChangePercent: number;
  todaysChangeAmount: number;
  todaysChangePercent: number;
  totalAssets: number;
  totalLiabilities: number;
  totalNetWorth: number;
  totalWealth: number;
}
export const MOCKPORTFOLIO: Portfolio = {
  accountIds: [
    "a1b2c3", "c3b4a5", "2e34f56g"
  ],
  netWorthChangeAmount: 1456.88,
  netWorthChangePercent: 1.56,
  todaysChangeAmount: 167.80,
  todaysChangePercent: 0.03,
  totalAssets: 852802.15,
  totalLiabilities: 821123.56,
  totalNetWorth: 2645165.76,
  totalWealth: 14774.37,
}

// export type Accordion = {
//   title: string,
//   total: number,
//   ugl?: {value: number, percentage: number},
//   tooltip: string,
//   accounts: Account[],
//   accountCategory: accountCategory,
// };