import { Component, OnInit } from '@angular/core';
import { AppState } from '@capacitor/app';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Client } from 'src/app/models/index.models';
import { DeviceService } from 'src/app/services/device.service';
import { getClient } from 'src/app/store/app-selectors';
import { getDarkmodeSetting } from 'src/app/store/settings-selectors';
import { DarkmodeOpts, SettingsState } from 'src/app/store/settings-store';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.page.html',
  styleUrls: ['./account-settings.page.scss'],
})
export class AccountSettingsPage implements OnInit {

  credentialsInstructionText = `Your username is your primary email address on file and where you will receive all future communications. Please contact your financial professional if you would like to change your primary email on file.`
  eDeliveryInstructionText1 = `If you'd like to set up eDelivery preferences for each individual account, log into`
  eDeliveryInstructionText2 = `For documents you choose to receive via U.S. mail there may be fees applied.`

  darkmodeSetting: DarkmodeOpts = 'device';
  client$: Observable<Client>;

  current_tab = "dashboard";
  public appPages = [
    { title: 'Home', url: 'dashboard', icon: 'home', tab: 'dashboard' },
    { title: 'Accounts', url: 'accounts', icon: 'wallet', tab: 'accounts' },
    { title: 'Documents', url: 'documents', icon: 'document-text', tab: 'documents' },
    { title: 'Financial Prof.', url: 'advisors', icon: 'person-circle', tab: 'advisors' },
  ];

  constructor(
    private store: Store<AppState & SettingsState>,
    private device: DeviceService
  ) {
    this.client$ = this.store.select(getClient);
  }

  ngOnInit() {
    this.store.select(getDarkmodeSetting).subscribe(( darkmode => {
      this.darkmodeSetting = darkmode.mode;
    }));
  }

  darkmodeSelection(event: any) {
    this.device.setDarkmode(event.detail.value);
  }

  notificationPreferanceSelection(event: any) {
    console.log(`changed notification option to ${event.detail.value}`);
  }

  eDeliverySelection(event: any) {
    console.log(`changed eDelivery option to ${event.detail.value}`);
  }

  biometricAuthSelection(event: any) {
    console.log(`changed biometric option to ${event.detail.value}`);
  }

  changePassword() {
    console.log("Trigger Change Password");
  }

}
