import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AccountsPageRoutingModule } from './accounts-routing.module';

import { AccountsPage } from './accounts.page';
import { SharedModule } from 'src/app/shared/shared.module';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { LinkAccountComponent } from './link-account/link-account.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AccountsPageRoutingModule,
    SharedModule
  ],
  declarations: [AccountsPage, PortfolioComponent, LinkAccountComponent]
})
export class AccountsPageModule { }
