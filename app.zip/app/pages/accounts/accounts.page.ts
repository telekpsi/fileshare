import { Component, OnInit } from '@angular/core';
import { MOCKPORTFOLIO } from 'src/app/models/index.mocks';
import { NetWorthHighlights, Portfolio } from 'src/app/models/index.models';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.page.html',
  styleUrls: ['./accounts.page.scss'],
})
export class AccountsPage implements OnInit {

  iAccountsOpened = false;
  lAccountsOpened = false;
  manualsOpened = false;
  aAccountsOpened = false;
  segment = 'all';

  constructor() { }

  ngOnInit() {
  }

  segmentChanged(event: any) {
    this.segment = event.detail.value;
  }

  // need to fetch the accounts of all three types and separate them into their sources, and sum up the total amount in each; but how does authorized work?
}
