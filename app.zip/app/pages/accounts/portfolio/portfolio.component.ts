import { Component, OnInit } from '@angular/core';
import { Subject, combineLatest, takeUntil } from 'rxjs';
import { Store } from "@ngrx/store"

import { getAccountCategoryInfo, getAccounts, getAllAccountCategoryInfo, getNetWorthHighlights, getUserId } from "../../../store/app-selectors";
import { AppState } from "../../../store/app-store";
import { Account, AccountsCategory, NetWorthHighlights } from 'src/app/models/index.models';
import { ModalService } from 'src/app/services/modal.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss'],
})
export class PortfolioComponent implements OnInit {
  portfolio: NetWorthHighlights = {} as NetWorthHighlights;
  unloadables: boolean = false;
  private readonly destroyed$ = new Subject();

  accounts = [];
  accordions: AccountsCategory[] = [
    {
      accountCategory: 'Investment',
      totalAccountsValue: 0,
      status: false,
      accounts: [],
    },
    {
      accountCategory: 'External',
      totalAccountsValue: 0,
      status: false,
      accounts: [],
    },
    {
      accountCategory: 'Asset',
      totalAccountsValue: 0,
      status: false,
      accounts: [],
    },
    {
      accountCategory: 'Authorized',
      totalAccountsValue: 0,
      status: false,
      accounts: [],
    },
  ];

  constructor(
    private store: Store<AppState>,
    private modalService: ModalService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.store.select(getUserId).subscribe((x) => {
      if (x == '000') {
        this.accordions.map((acc) => acc.accounts = []);
      } else {
        this.store.select(getAllAccountCategoryInfo)
          .pipe(takeUntil(this.destroyed$)).subscribe( (accountCategories) => {
            this.accordions = this.accordions.map((accordion: AccountsCategory) => {
              let info = accountCategories.filter(aInfo => (aInfo.accountCategory == accordion.accountCategory));
              accordion = info.length > 0 ? info[0] : accordion;
              // TODO: make this actually handle if no hasBrokenLink
              this.unloadables = accordion.accountCategory == 'External' ? accordion.status! : this.unloadables;
              return accordion
            });
        });
        this.store.select(getNetWorthHighlights).pipe(takeUntil(this.destroyed$)).subscribe((highlights) => this.portfolio = highlights);
        
      }
    });
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation()?.extras.state && this.router.getCurrentNavigation()?.extras.state?.['linkAccounts'] == 'open') {
        this.onLinkAccounts();
      }
    });
  }

  private isManual(account: Account) {
    return (account.accountCategory == 'Asset' || account.accountCategory == 'Liability')
  }

  onManageAccounts() {

  }

  onLinkAccounts() {
    this.modalService.createLinkModal();
  }
}