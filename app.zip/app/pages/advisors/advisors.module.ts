import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdvisorsPageRoutingModule } from './advisors-routing.module';

import { AdvisorsPage } from './advisors.page';
import { SharedModule } from "../../shared/shared.module";

@NgModule({
  declarations: [AdvisorsPage],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdvisorsPageRoutingModule,
    SharedModule
  ]
})
export class AdvisorsPageModule { }
