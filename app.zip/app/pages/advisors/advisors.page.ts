import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { Advisor } from 'src/app/models/advisor';
import { getAdvisors } from 'src/app/store/app-selectors';
import { AppState, SetAdvisorPrimary } from 'src/app/store/app-store';

@Component({
  selector: 'app-advisors',
  templateUrl: './advisors.page.html',
  styleUrls: ['./advisors.page.scss'],
})
export class AdvisorsPage implements OnInit {
  advisors$: Observable<Advisor[]>;

  constructor(private store: Store<AppState>, private alertCtrl: AlertController) {
    this.advisors$ = this.store.select(getAdvisors);
  }

  ngOnInit() {}

  async openPrimaryAlert(advisor: Advisor) {
    const alert = await this.alertCtrl.create({
      header: `Are you sure you wish to make ${advisor.name.full} your new primary advisor?`,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {},
        },
        {
          text: 'Yes',
          role: 'confirm',
          handler: () => {
            this.makePrimary(advisor);
          },
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    
  }

  makePrimary(newPrimary: Advisor) {
    this.store.dispatch(SetAdvisorPrimary({ advisorId: newPrimary.advisorId }));
  }
}
