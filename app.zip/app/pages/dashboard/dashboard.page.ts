import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, Subject, takeUntil } from 'rxjs';
import { AccountsCategory, NetWorthHighlights } from 'src/app/models/index.models';
import { getAccountCategoryInfo, getClient, getNetWorthHighlights, getUserId } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';
import { Client } from 'src/app/models/index.models';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {
  private readonly destroyed$ = new Subject();

  portfolio: NetWorthHighlights = {} as NetWorthHighlights;
  menu: string = 'none';
  isOpen: boolean = true;
  token: string = '';
  client$: Observable<Client>;
  unloadables: boolean = false;

  constructor(private router: Router, private store: Store<AppState>) {
    this.client$ = this.store.select(getClient);
  }

  accordion: AccountsCategory = {
    accountCategory: 'Investment',
    totalAccountsValue: 0,
    status: false,
    accounts: [],
  } 

  ngOnInit() {
    this.store.select(getUserId).subscribe((x) => {
      if (x == '000') {
        this.accordion.accounts = [];
      } else {
        this.store.select(getAccountCategoryInfo('Investment'))
          .pipe(takeUntil(this.destroyed$)).subscribe( (accountCategoryInfo) => {
            let info = accountCategoryInfo.filter(aInfo => (aInfo.accountCategory == this.accordion.accountCategory));
            this.accordion = info.length > 0 ? info[0] : this.accordion;
            // this.unloadables = this.accordion.status.includes('Broken Yodlee Link');
        });
        this.store.select(getNetWorthHighlights)
          .pipe(takeUntil(this.destroyed$))
          .subscribe((highlights) => this.portfolio = highlights)
        this.store.select(getAccountCategoryInfo('External'))
          .pipe(takeUntil(this.destroyed$)).subscribe((accountCategoryInfo) => {
            let info = accountCategoryInfo.filter(aInfo => (aInfo.accountCategory == 'External'));
            // TODO: make this actually handle if no hasBrokenLink
            this.unloadables = info.length > 0 ? info[0].status! : false;
          });
      }
    });
  }

  onManageAccounts() {
    this.router.navigate(['aw/accounts']);
  }

  onLinkAccounts() {
    this.router.navigate(['aw/accounts'], {state: {linkAccounts: 'open'}})
  }
}
