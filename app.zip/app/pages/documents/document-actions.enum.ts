const actions = {
    UPLOAD: {icon: 'share-outline', label: 'Upload'},
    DOWNLOAD: {icon: 'download-outline', label: 'Download'},
    MOVECOPY: {icon: 'duplicate-outline', label: 'Move or Copy'},
    MOVE: {icon: '', label: 'Move'},
    COPY: {icon: '', label: 'Copy'},
    RENAME: {icon: 'pencil-outline', label: 'Rename'},
    DELETE: {icon: 'trash-outline', label: 'Delete'},
    CREATE: {icon: 'add-circle-outline', label: 'Create New Folder'},
    SHARE: {icon: 'people-outline', label: 'Share'},
}

export const topLevel = [
    actions.CREATE,
    actions.UPLOAD
];
export const single = [
    actions.DOWNLOAD,
    actions.MOVECOPY,
    actions.RENAME,
    actions.DELETE,
    actions.SHARE,
];
export const multi = [
    actions.DOWNLOAD,
    actions.MOVECOPY,
    actions.DELETE,
]