import { Component, Input } from '@angular/core';
import { BoxItem } from 'src/app/models/documents.model';

@Component({
  selector: 'app-document-box-card',
  templateUrl: './document-box-card.component.html',
  styleUrls: ['./document-box-card.component.scss'],
})
export class DocumentBoxCardComponent {
  @Input() selected?: boolean;
  @Input() item?: BoxItem;

  constructor() { }

}
