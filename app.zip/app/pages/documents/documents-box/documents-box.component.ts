import { Component, OnInit } from '@angular/core';
import { Platform } from '@ionic/angular';
import { BoxItem } from 'src/app/models/documents.model';
import { DocumentsService } from 'src/app/services/documents.service';
import * as docActions from '../document-actions.enum';
import { ModalService } from 'src/app/services/modal.service';

@Component({
  selector: 'app-documents-box',
  templateUrl: './documents-box.component.html',
  styleUrls: ['./documents-box.component.scss'],
})
export class DocumentsBoxComponent implements OnInit {
  tooltip = `In order to share documents with others,
   please go into your "My Files" folder. All other 
   folders are shared by default with your professional 
   team. In order to upload, please go into one of the folders below`;
  loading: boolean = false;
  documentTreeRoot: BoxItem = {} as BoxItem;
  currentFolder: BoxItem = {} as BoxItem;
  selection: BoxItem[] = [];
  errorState?: {
    title?: string,
    body: string,
    type: 'error' | 'warning',
  }
  screenHeight: number = 0;

  constructor(private documentsService: DocumentsService, private modalService: ModalService, platform: Platform) {
    this.loading = true;
    this.documentsService.getDocumentsFolder('0').then(items => {
      this.documentTreeRoot = items[0];
      this.currentFolder = items[0];
      this.loading = false;
    });
    platform.ready().then(() => {
      this.screenHeight = platform.height();
    });
  }

  ngOnInit() {}

  async showDocumentActions() {
    let options = (this.selection.length == 0) ? docActions.topLevel :
      (this.selection.length == 1) ? docActions.single : docActions.multi;
    let percentage = ((options.length * 40) + 86) / this.screenHeight;
    const {data, role} = await this.modalService.createDocumentActionsModal(percentage,options);

    if (role=='error') {
      this.errorState == data;
    }
    if (data) {
      switch (data.action) {
        default:
          console.log(data.action)
      }
    }
  }

  selected(item: BoxItem) {
    if (this.selection.includes(item)) {
      this.selection = this.selection.filter(i => i !== item)
    } else {
      this.selection.push(item);
    }
  }

  opened(item: BoxItem) {
    // if in selection mode, add or remove from selection set
    if (this.selection.length > 0) {
      if (this.selection.includes(item)) {
        this.selection = this.selection.filter(i => i !== item)
      } else {
        this.selection.push(item);
      }
    } else if (item.folder) {
      this.loading = true;
      this.selection = [];
      const folderId = item.id;
      this.documentsService.getDocumentsFolder(folderId).then(folderContents => {
        item.parentFolder = this.currentFolder;
        item.data = folderContents;
        this.currentFolder = item;
        this.loading = false;
      });
    } else {
      console.log("not a folder!")
      //open file preview
    }
  }

  returnFolderLevel() {
    if(this.currentFolder.parentFolder) {
      this.selection = [];
      this.currentFolder = this.currentFolder.parentFolder;
    } else {
      console.log('No Parent Folder!')
    }
  }

}