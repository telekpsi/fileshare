import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling'

import { IonicModule } from '@ionic/angular';

import { DocumentsPageRoutingModule } from './documents-routing.module';

import { DocumentsPage } from './documents.page';
import { SharedModule } from 'src/app/shared/shared.module';
import { DocumentsBoxComponent } from './documents-box/documents-box.component';
import { DocumentBoxCardComponent } from './document-box-card/document-box-card.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DocumentsPageRoutingModule,
    ScrollingModule,
    SharedModule
  ],
  declarations: [DocumentsPage, DocumentsBoxComponent, DocumentBoxCardComponent]
})
export class DocumentsPageModule { }
