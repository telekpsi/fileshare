import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SecureStorage } from '@aparajita/capacitor-secure-storage';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.page.html',
  styleUrls: ['./documents.page.scss'],
})
export class DocumentsPage implements OnInit {
  segment = 'box';

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {}

  segmentChanged(event: any) {
    this.segment = event.detail.value;
  }
}
