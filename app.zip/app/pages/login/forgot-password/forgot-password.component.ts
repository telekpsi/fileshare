import { Component, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { AuthenticationProfile } from 'src/app/models/index.models';
import { AuthService } from 'src/app/services/auth.service';
import { ForgotPasswordService } from 'src/app/services/forgot-password.service';
import { SingleAuthMechanismRequest } from 'src/app/services/models/security.model';
import { CustomValidators, MismatchValidator } from 'src/app/shared/custom-validators';
import { AppState, OpenedAuthentication } from 'src/app/store/app-store';

export type flowStep = 'enter email' | 'enter ssn' | 'select phone' | 'enter OTP' | 'change password' | 'done' | 'error';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnInit {
  @Output() errorState = ''
  step: flowStep;
  isProspect: boolean = true;
  private readonly destroyed$ = new Subject()
  passwordForm!: FormGroup;
  promiseProf: AuthenticationProfile = {} as AuthenticationProfile;
  tels: string[] = [];
  buttonText: string = "Next"
  newRevealed: boolean = false;
  confirmRevealed: boolean = false;
  new_password_type: string = 'password'
  confirm_password_type: string = 'password'

  constructor(
    private modalController: ModalController,
    private fb: FormBuilder,
    private authService: AuthService,
    private forgotPasswordService: ForgotPasswordService,
    private store: Store<AppState>
  ) {
    this.step = 'enter email';
  }

  // passwordForm = this.fb.group({
  //   initEmail: [''],
  // })

  ngOnInit() {
    this.passwordForm = new FormGroup(
      {
      initEmail: new FormControl('',[Validators.email, Validators.required]),
      },
      // {
      //   validator: 
      // }
    );
    this.step = 'enter email';
  }

  proceed() {
    if (this.step=='done') {
      this.modalController.dismiss(this.step, 'success');
    } else {
      this.advStep();
    }
  }

  async advStep() {
    switch(this.step) {
      case 'enter email':
        await this.requestAuth(this.passwordForm.get('initEmail')?.value);
        break;
      case 'enter ssn':
        await this.submitSsn(this.passwordForm.get('ssn')?.value);
        break;
      case 'select phone':
        await this.requestOTP(this.passwordForm.get('phone')?.value);
        break;
      case 'enter OTP':
        await this.submitOTP(this.passwordForm.get('otp')?.value, this.passwordForm.get('initEmail')?.value);
        break;
      case 'change password':
        await this.changePassword(this.passwordForm.get('password')?.value);
        break;
      default:
        await this.stepError();
        break;
    }
  }

  async requestAuth(username: string) {
    // logic based off email-prospect check
    const reason = 'ForgotPassword';
    this.promiseProf = await this.forgotPasswordService.invokeForgotAuthentication(this.passwordForm.get('initEmail')?.value,reason);
    if (!this.promiseProf.allowForgotPassword) {
      this.stepError();
    } else {
      this.store.dispatch(OpenedAuthentication({auth: this.promiseProf}))
      let hasSsn = await this.authService.applyAuthenticationMechanism({Action: reason, SessionId: this.promiseProf.sessionId} as SingleAuthMechanismRequest)
      // TODO: passback error state as well
      if (hasSsn) {
        // this.passwordForm.addControl('nonProspectEmail', new FormControl(this.passwordForm.get('initEmail')?.value,[Validators.email, Validators.required]));
        this.passwordForm.addControl('ssn', new FormControl('',[Validators.required, Validators.minLength(4), Validators.maxLength(4),Validators.pattern("^[0-9]*$")]));
        // TODO: simplify since initEmail can just be readonly if they are not a prospect
        // this.passwordForm.removeControl('initEmail');
        this.step = 'enter ssn'
        this.isProspect=false;
      } else if (hasSsn==false) {
        this.passwordForm.addControl('phone', new FormControl('0522',[Validators.required]))
        this.step = 'select phone'
        this.isProspect=true;
      } else {
        this.stepError();
      }
    }
  }

  submitSsn(ssn: string) {
    // TODO find web hash for SSN
    /*
    res = ath.advanceAuth(ssn)
    if (res.error)
      return this.stepError();
    else
      return 'select phone';
    */

  //  TODO: once we have validatessn salt
    // this.authService.validateSSN(ssn, this.passwordForm.get('initEmail')?.value()).then((isSuccess) => {
    //   if(isSuccess) {
    //     this.passwordForm.addControl('phone', new FormControl('0522',[Validators.required]))
    //     this.step = 'select phone'
    //   } else {
    //     console.log("invalid SSN")
    //     this.stepError();
    //   }
    // });
    
    this.passwordForm.addControl('phone', new FormControl('0522',[Validators.required]))
    this.step = 'select phone'
  }

  async requestOTP(phonenumber: any) {
    let success = await this.authService.requestOTP(this.passwordForm.get('phone')?.value);
    if (success) {
      this.passwordForm.addControl('otp', new FormControl('',[Validators.required,Validators.pattern("^[0-9]*$")]));
      this.step = 'enter OTP'
    } else {
      this.stepError();
    }
  }

  async submitOTP(otp: string, email: string) {
    let success = await this.authService.submitOtp(this.passwordForm.get('otp')?.value.toString(),this.passwordForm.get('phone')?.value, 'forgotPassword');
    if(success.data.result) {
      // const reg: RegExp = new RegExp(`($(email))`,'i');
      this.passwordForm.addControl('password', new FormControl('',[
        Validators.required,
        CustomValidators.patternValidator(/\d/, {
          hasNumber: true
        }),
        // check whether the entered password has upper case letter
        CustomValidators.patternValidator(/[A-Z]/, {
          hasCapitalCase: true
        }),
        // check whether the entered password has a lower case letter
        CustomValidators.patternValidator(/[a-z]/, {
          hasSmallCase: true
        }),
        // CustomValidators.patternValidator(/(password)/i,{hasPassword:true}),
        // CustomValidators.patternValidator(reg,{hasUsername:true}),
        // check whether the entered password has a special character
        CustomValidators.patternValidator(/[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, {
          hasSpecialCharacters: true
        }),
        Validators.minLength(8),
        this.PasswordInPasswordValidation(),
        this.EmailInPasswordValidation(),
      ]));
      this.passwordForm.addControl('confirmPassword', new FormControl('',[Validators.required,this.ConfirmPasswordValidation()]));
      this.buttonText = "Submit";
      this.step = 'change password';
      this.passwordForm.errors?.[''];
      this.passwordForm.get('password')?.valueChanges.subscribe(value => {
        if (value.length > 0 && this.passwordForm.get('confirmPassword')?.value.length > 0) {
          this.passwordForm.get('confirmPassword')?.updateValueAndValidity();
        }
      })
    } else {
      this.stepError();
    }
  }

  PasswordInPasswordValidation(): ValidatorFn {
    return (control: AbstractControl) : ValidationErrors | null => {
      const value: string = control.value;
      if (!value || value == '') {
        return null
      }
      const invalid = (value.toLowerCase().includes('password'.toLowerCase()));
      return invalid ? {passwordInPassword: true} : null;
    }
  }

  EmailInPasswordValidation(): ValidatorFn {
    return (control: AbstractControl) : ValidationErrors | null => {
      const value: string = control.value;
      if (!value || value == '') {
        return null
      }
      const invalid = (value.toLowerCase().includes(this.passwordForm.get('initEmail')?.value.split('@')[0].toLowerCase())) ||
      (value.replace(/[^a-zA-Z]/g, '').toLowerCase().includes(this.passwordForm.get('initEmail')?.value.split('@')[0].replace(/[^a-zA-Z]/g, '').toLowerCase()));
      return invalid ? {emailInPassword: true} : null;
    }
  }

  ConfirmPasswordValidation(): ValidatorFn {
    return (control: AbstractControl) : ValidationErrors | null => {
      const value = control.value;
      if (!value || value == '') {
        return null
      }
      const valid = (value == this.passwordForm.get('password')?.value);
      return !valid ? {passwordMismatch: true} : null
    }
  }

  async changePassword(newPassword: string) {
    /*
    res = service.call(newPassword)
    if (res.error)
      return this.stepError();
    return router.navigate['/login']
    */
  if (this.passwordForm.get('password')?.value == this.passwordForm.get('confirmPassword')?.value) {
    let success = await this.forgotPasswordService.resetPassword(this.passwordForm.get('password')?.value);
    if(success) {
      this.buttonText = "Log In";
      this.clearForm();
      this.step = 'done'
    } else {
      this.stepError();
    }
  } else {
    this.stepError();
  }
  }

  togglePassword(field: string) {
    if (field=='new'){
      this.newRevealed = !this.newRevealed;
      this.new_password_type = this.new_password_type === 'text' ? 'password' : 'text';
    } else {
      this.confirmRevealed = !this.confirmRevealed;
      this.confirm_password_type = this.confirm_password_type === 'text' ? 'password' : 'text';
    }
  }

  clearForm() {
    this.passwordForm.contains('changePassword') ? this.passwordForm.removeControl('changePassword') : null;
    this.passwordForm.contains('password') ? this.passwordForm.removeControl('password') : null;
    this.passwordForm.contains('otp') ? this.passwordForm.removeControl('otp') : null;
    this.passwordForm.contains('phone') ? this.passwordForm.removeControl('phone') : null;
    this.passwordForm.contains('ssn') ? this.passwordForm.removeControl('ssn'): null;
    this.passwordForm.removeControl('initEmail');
    this.passwordForm.addControl('initEmail', new FormControl('',[Validators.email, Validators.required]));
    this.isProspect = true;
    this.passwordForm.reset();
  }

  returnToStart(error?: boolean) {
    if (error) {
      this.stepError();
    } else {
      this.clearForm();
      this.step="enter email";
    }
  }

  stepError() {
    this.clearForm();
    return this.modalController.dismiss(this.getErrorMessage(), 'error');
    // text alterations to top text or else have an error page that can proceed to the 2nd page
  }

  getErrorMessage(){
    switch(this.step) {
      case 'enter email':
      case 'enter ssn':
        return {title: "User Not Found",
        body: "The username and/or SSN/TIN that you entered does not match our records, please try again.", type: 'error'}
      case 'enter OTP':
        return {title:"Invalid One-Time Passcode", body: "Let's try again. It looks like the code that you entered didn't match.", type: 'error'}
      case 'change password':
        return {title:"Invalid Password", body:'The password you requested to change to is not a valid password for Adviceworks', type: 'error'}
      default:
        return {title:"Unknown Error",
        body: "We're sorry, we don't know what went wrong! Please try again in a few minutes. If the issue persists, you can call the Support Desk at (000) 000-0000", type: 'error'}
    }
  }

  cancel(reason: string) {
    this.clearForm();
    return this.modalController.dismiss(this.step, 'cancel');
  }

  get errorControl() {
    return this.passwordForm.controls;
  }
}
