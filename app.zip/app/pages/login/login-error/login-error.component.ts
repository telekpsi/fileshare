import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-login-error',
  templateUrl: './login-error.component.html',
  styleUrls: ['./login-error.component.scss'],
})
export class LoginErrorComponent  implements OnInit {

  constructor(private modalController: ModalController) { }

  ngOnInit() {}

  cancel(reason: string) {
    return this.modalController.dismiss(null, 'cancel');
  }
}
