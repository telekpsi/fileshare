import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { AuthenticationProfile } from 'src/app/models/authentication';
import { AuthService } from 'src/app/services/auth.service';
import { getAuthProfile } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';

export type flowStep = 'enter email' | 'enter ssn' | 'select phone' | 'enter OTP' | 'change password' | 'done' | 'error';

@Component({
  selector: 'app-login-otp',
  templateUrl: './login-otp.component.html',
  styleUrls: ['./login-otp.component.scss'],
})
export class LoginOtpComponent  implements OnInit {
  @Input() encryptedPassword: string = '';
  @Input() userName: string = '';
  step: flowStep = 'select phone';
  promiseProf!: AuthenticationProfile;
  phone = '';
  otpPasscode!: number;

  constructor(
    private modalController: ModalController,
    private store: Store<AppState>,
    private authService: AuthService) {
    this.step = 'select phone'
  }

  ngOnInit() {
    this.store.select(getAuthProfile).subscribe((profile)=>{
      this.promiseProf = profile;
      this.phone = profile.otpMechanisms[0].number;
    });
  }

  cancel() {
    return this.modalController.dismiss();
  }

  async proceed() {
    if(this.step == 'select phone') {
      let success = await this.authService.requestOTP(this.phone);
      // if returns success, proceed, otherwise go to error page?
      if (success) {
        this.step = 'enter OTP'
        null;
      } else {
        this.modalController.dismiss({title:"", body: "Let's try again. It looks like something went wrong."}, 'error');
      }
    } else {
      let authBody;
      // let success = await this.authService.submitOtp(this.otpPasscode.toString(),this.phone,'loginOtp');
      this.authService.submitOtp(this.otpPasscode.toString(),this.phone,'loginOtp').then((resp) => {
        if(resp.data.result) {
          // this.modalController.dismiss(resp.data.authBody, 'success');
          authBody = resp.data.authBody;
        } else {
          this.modalController.dismiss({title:"Invalid One-Time Passcode", body: "Let's try again. It looks like the code that you entered didn't match."}, 'error');
        }
      });
      // verify this doesn't go in infinite loop with wrong otp code
      while (authBody == null || authBody == undefined ) {
        await new Promise(resolve => setTimeout(resolve,1000));
      }
      let resp;
      resp = await this.authService.submitSSO(authBody,this.encryptedPassword,this.userName);
      this.modalController.dismiss(resp.data, 'success');
    }
  }
}
