import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";
import { switchMap, map, tap, mergeMap, mergeAll } from "rxjs";
import { AccountsService } from "src/app/services/accounts.service";
import { AdvisorService } from "src/app/services/advisor.service";
import { AuthService } from "src/app/services/auth.service";
import { ClientService } from "src/app/services/client.service";
import { DeviceService } from "src/app/services/device.service";
import { HoldingsTransactionsService } from "src/app/services/holdings-transactions.service";
import { NetWorthService } from "src/app/services/net-worth.service";
import { AuthenticatedUser, LoadedAdvisorInfo, LoadedUserInfo, UserLoggedIn, UserLoggedOut, SetEnteredToken } from "src/app/store/app-store";

@Injectable()
export class LoginEffects {

  constructor(
    private actions$: Actions,
    private authService: AuthService,
    private clientService: ClientService,
    private advisorService: AdvisorService,
    private deviceService: DeviceService,
    private accountsService: AccountsService,
    private holdingsService: HoldingsTransactionsService,
    private netWorthService: NetWorthService,
    private router: Router,
  ) { }

  login$ = createEffect(() => this.actions$.pipe(
    ofType(UserLoggedIn),
    map(action => action.signin),
    map((signin) => AuthenticatedUser({ authToken: signin.token, userId: signin.email=='empty@admin.com' ? '000' : '001'})),
    tap(() => {
      this.router.navigate(['/aw/dashboard']);
    }),
  ));

  logout$ = createEffect(() => this.actions$.pipe(
    ofType(UserLoggedOut),
    switchMap(() =>
      this.authService.logout().pipe(
        tap(() => {
          this.router.navigate(['/aw-login'])
        }),
      )
    ),
  ), { dispatch: false });

  authenticatedUser$ = createEffect(() => this.actions$.pipe(
    ofType(AuthenticatedUser),
    map(action => [action.authToken, action.userId]),
    tap( ([token, user]) => {
      this.clientService.getClient(token);
      this.clientService.getNotificationLabels(token);
      this.clientService.getNotifications(token);
      this.accountsService.loadAccounts(token);
      this.advisorService.getClientAdvisors(token);
      this.netWorthService.getNetWorthHighlights(token);
      this.netWorthService.getNetWorthHistory(user);
      // this.holdingsService.getAllAccountHoldings(token);
      this.accountsService.getAllocationData(token);
    })
  ), { dispatch: false })

}

