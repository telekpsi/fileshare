import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LoginPageRoutingModule } from './login-routing.module';

import { LoginPage } from './login.page';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { SharedModule } from "../../shared/shared.module";
import { LoginOtpComponent } from './login-otp/login-otp.component';
import { LoginErrorComponent } from './login-error/login-error.component';

@NgModule({
    declarations: [LoginPage, ForgotPasswordComponent, LoginOtpComponent, LoginErrorComponent],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        IonicModule,
        LoginPageRoutingModule,
        SharedModule
    ]
})
export class LoginPageModule {}
