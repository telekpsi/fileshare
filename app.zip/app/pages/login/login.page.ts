import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, IonInput, ModalController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { tap } from 'rxjs';

import { AppState, OpenedAuthentication, SetLastLogin, UserLoggedIn } from '../../store/app-store';
import { isLoggedIn } from '../../store/app-selectors';
import { AuthService } from 'src/app/services/auth.service';
import { LoginPrefill } from 'src/app/store/settings-selectors';
import { SaveCredentialsSetting } from 'src/app/store/settings-store';
import { DeviceService } from 'src/app/services/device.service';
import { SecureStorage } from '@aparajita/capacitor-secure-storage';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { statusMessage } from 'src/app/models/common/messages';
import { LoginOtpComponent } from './login-otp/login-otp.component';
import { LoginErrorComponent } from './login-error/login-error.component';
import { SingleAuthMechanismRequest } from 'src/app/services/models/security.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  password_type: string = 'password';
  prefersDark!:any;
  loginAction: string = "Answer";
  constructor(
    private store: Store<AppState>, 
    private router: Router, 
    private modalController: ModalController,
    private alertController: AlertController,
    private authService: AuthService,
    private deviceService: DeviceService,
    ) { }

  loginLogin = {
    email: '',
    password: '',
    saveCredentials: false,
    token: ''
  }
  revealed: boolean = false;
  errorState?: {
    title?: string,
    body: string,
    type: 'error' | 'warning',
  }

  key = 'mobilePw';
  prefix = 'adviceworks.mobile';

  @ViewChild('loginFormForm') public loginFormForm!: NgForm;
  @ViewChild('password') public passwordInput!: IonInput;

  ionViewWillEnter() {
    this.revealed = false;
    this.loginFormForm.resetForm();
    
    this.store.select(LoginPrefill).pipe(tap(
      (prefill: SaveCredentialsSetting) => {
        this.loginLogin.email = (prefill.username || '');
        // this.loginLogin.password = (prefill.password || '');
        this.loginLogin.saveCredentials = (prefill.saveCredentials || false);
      })).subscribe(() =>
        this.initialStorageHandling()
    );
    this.store.select(isLoggedIn).pipe(
      tap((l) => l ? this.router.navigateByUrl('/aw/dashboard') : false),
    );
    // maybe pass password here?
  }

  async initialStorageHandling(): Promise<void> {
    await SecureStorage.setKeyPrefix(this.prefix)
    this.loginLogin.password = this.loginLogin.saveCredentials ? await SecureStorage.getItem(this.key) || '' : '';
    SecureStorage.getItem(this.key).then((value)=>console.log(value));
  }

  togglePassword() {
    this.revealed = !this.revealed;
    this.password_type = this.password_type === 'text' ? 'password' : 'text';
  }

  ionViewWillLeave() {
    this.loginLogin.email='';
    this.loginLogin.password='';
    this.errorState = undefined;
  }

  async auth(login: NgForm) {
    // TODO: we will probably remove the hash below, just don't want to mess with a ton of stuff when testing basic functionality, so replacing with normal string
    this.errorState = undefined;
    const encryptedPassword = this.authService.encryptPassword(login.value.password);
    let startData = (await this.authService.invokeLoginAuthentication(login.value.email, login.value.password, this.loginAction)).data;
    if (startData.result == 'LoginSuccess') {
      let resp = (await this.authService.submitSSO(startData, encryptedPassword, login.value.email)).data;
      this.store.dispatch(SetLastLogin({lastLogin: resp.lastLogin}));
      this.store.dispatch(UserLoggedIn({ signin: {email: login.value.email, passwordhash: encryptedPassword, token: resp.token} }));
    } else {
      this.store.dispatch(OpenedAuthentication({auth: startData.authProfile}));
      this.authService.applyAuthenticationMechanism({Action: this.loginAction, Answer: login.value.password, MechanismId: startData.authProfile.passwordMechanismId, SessionId: startData.authProfile.sessionId} as SingleAuthMechanismRequest).then((resp) => {
        if (resp.error) {
          this.openError();
        } else if (resp.data) {
          this.openOTP(login, encryptedPassword);
        } else {
          this.store.dispatch(UserLoggedIn({ signin: {email: login.value.email, passwordhash: login.value.password, token: login.value.token} }));
          this.deviceService.setLocalSetting('saveCredentials', login.value.saveCredentials);
          if (login.value.saveCredentials) {
            this.deviceService.storeCredentials(login.value.email,login.value.password);
            SecureStorage.setItem(this.key,login.value.password);
          } else {
            this.deviceService.destroyStoredCredentials();
            SecureStorage.removeItem(this.key);
          }
        }
      });
    }
  }

  async secretAuth(login: NgForm) {
    const alert = await this.alertController.create({
      header: 'Enter token below:',
      inputs: [{type: 'textarea', name: 'token'}],
      buttons: [{text: 'Log In', handler: (alertData) => {
        this.store.dispatch(UserLoggedIn({ signin: {email: "admin@admin.com", passwordhash:"gibberish", token: alertData.token} }));
      }}],
    });
    await alert.present();

  }
  async secretSecretAuth(login: NgForm) {
    const alert = await this.alertController.create({
      header: 'Enter token below:',
      inputs: [{type: 'textarea', name: 'token'}],
      buttons: [{text: 'Log In', handler: (alertData) => {
        this.store.dispatch(UserLoggedIn({ signin: {email: "empty@admin.com", passwordhash:"gibberish", token: alertData.token} }));
      }}],
    });
    await alert.present();
  }

  // toggleDarkTheme(shouldAdd: any) {
  //   document.body.classList.toggle('dark', shouldAdd);
  // }

  async openForgotPassword() {
    this.errorState = undefined;
    const modal = await this.modalController.create({
      component: ForgotPasswordComponent,
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();
    if (role=='error') {
      this.errorState = {
        title: data?.title,
        body: data?.body,
        type: 'error'
      }
    } else if (role=='success') {
      this.errorState = undefined;
      this.loginLogin.saveCredentials = false;
      this.loginLogin.password = '';
      this.deviceService.destroyStoredCredentials();
      SecureStorage.removeItem(this.key);
    }
  }

  async openOTP(login: NgForm, encryptedPassword: string) {
    const modal = await this.modalController.create({
      component: LoginOtpComponent,
      componentProps: {
        encryptedPassword: encryptedPassword,
        userName: login.value.email
      },
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();
    if (role == 'error') {
      this.errorState = {
        title: data?.title,
        body: data?.body,
        type: 'error'
      }
    } else if (role == 'success') {
      this.store.dispatch(SetLastLogin({lastLogin: data.lastLogin}));
      this.store.dispatch(UserLoggedIn({ signin: {email: login.value.email, passwordhash: encryptedPassword, token: data.token} }));

      this.deviceService.setLocalSetting('saveCredentials', login.value.saveCredentials);
      if (login.value.saveCredentials) {
        this.deviceService.storeCredentials(login.value.email,login.value.password);
        SecureStorage.setItem(this.key,login.value.password);
      } else {
        this.deviceService.destroyStoredCredentials();
        SecureStorage.removeItem(this.key);
      }
    }
  }

  async openError() {
    const modal = await this.modalController.create({
      component: LoginErrorComponent,
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();
    if (role == 'reset') {
      this.openForgotPassword();
    } else {
// nothing?
    }
  }

  click(){
    console.log('clicked');
  }
  press() {
    console.log('pressed');
  }
}
