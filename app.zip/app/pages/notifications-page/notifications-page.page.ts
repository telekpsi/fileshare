import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notifications-page',
  templateUrl: './notifications-page.page.html',
  styleUrls: ['./notifications-page.page.scss'],
})
export class NotificationsPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
