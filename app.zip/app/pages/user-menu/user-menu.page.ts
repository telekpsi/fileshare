import { Component, OnInit } from '@angular/core';
import { AppState } from '@capacitor/app';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Client } from 'src/app/models/index.models';
import { ModalService } from 'src/app/services/modal.service';
import { getClient, getLastLogin } from 'src/app/store/app-selectors';

@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.page.html',
  styleUrls: ['./user-menu.page.scss'],
})
export class UserMenuPage implements OnInit {
  client$: Observable<Client>;
  lastLogin$: Observable<string>;

  constructor(private store: Store<AppState>, private modalService: ModalService) {
    this.client$ = this.store.select(getClient);
    this.lastLogin$ = this.store.select(getLastLogin);
    this.client$.subscribe((client)=> {
      console.log(client.mailingAddress)
    })
  }

  ngOnInit() {}

  onCloseModal() {
    this.modalService.menu='none';
    this.modalService.toggleMenu();
  }
}
