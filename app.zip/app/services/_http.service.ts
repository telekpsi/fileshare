import { Injectable } from "@angular/core";
import { CapacitorHttp } from "@capacitor/core";

import { environment } from "../../environments/environment"

@Injectable({ providedIn: 'root' })
export class CFGHttpService {
    // RETRY_COUNT = 3

    constructor() {}

    serviceHeaders = {
        'Content-Type': 'application/json',
    }

    async GET<T>(url: string, headers: {}, mapper?: ((_:any)=>T)): Promise<T> {
        let response = await CapacitorHttp.get({
            url: environment.API_ENDPOINT+url,
            headers: {
                ...this.serviceHeaders,
                ...headers,
            },
        }).catch(error => {
            console.error(error);
        });
        if (mapper) {return mapper(response?.data)}
        else {return response?.data};
    }

    async POST<T>(url: string, body: any, headers: {}, mapper?: ((_:any)=>T)): Promise<T> {
        let response = await CapacitorHttp.post({
            url: environment.API_ENDPOINT+url,
            headers: {
                ...this.serviceHeaders,
                ...headers,
            },
            data: body,
        }).catch(error => {
            console.error(error);
        });
        if (mapper) {return mapper(response?.data)}
        else {return response?.data};
    }

}