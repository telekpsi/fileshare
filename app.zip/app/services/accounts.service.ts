import { Injectable } from "@angular/core"
import { HttpClient } from "@angular/common/http";
import { Store } from "@ngrx/store"
import { combineLatest, mergeAll, retry } from "rxjs";

import { Account, AllocationData } from "../models/index.models";
import { LoadedAccountCategoryInfo, AppState, LoadedAllocationData } from "../store/app-store";
import { AccountCategoryResponse, AccountResponse, AccountsResponse } from "./models/accounts.model";
import { AllocationResponseData } from "./models/allocations.model";
import { accountCategory, AccountsCategory } from "../models/account.model";
import { environment } from "../../environments/environment"

@Injectable({ providedIn: 'root' })
export class AccountsService {
  constructor(private store: Store<AppState>, private httpService: HttpClient) {};

  loadAccounts(token: string): void {
    const url = environment.API_ENDPOINT + '/api/account/v1/experience/accounts/overview';
    const accountTypes = ['internal', 'authorized', 'external', 'manual'];
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    combineLatest([
      accountTypes.map( (type: string) => this.httpService.get<AccountsResponse>(`${url}?accountType=${type}`, {
        headers: headers,
        responseType: "json",
        observe: "body",
      })),
    ]).pipe(mergeAll(),mergeAll()).subscribe((accountType: AccountsResponse) => {
      accountType.accountsByCategory.map(category => {
        this.store.dispatch(LoadedAccountCategoryInfo({accountCategoryInfo: this.toAccountsCategory(category)}));
      });
    });
  }

  toAccountsCategory(category: AccountCategoryResponse): AccountsCategory {
    let accounts: Account[] = category.accounts.map(account => this.toAccount(account));
    let c: AccountsCategory = {
      accountCategory: this.normalizeAccountCategoryName(category.category),
      totalAccountsValue: category.totalAccountCategoryValue,
      // status: [...new Set(accounts.map(account => account.status))],
      status: accounts.some((account) => account.hasBrokenLink),
      // status: accounts.reduce( (account, status: accountsDataStatus[]) =>
        // [...status, ...account.status.filter((s: accountsDataStatus) => status.includes(s))], ([]:accountsDataStatus)),
      accounts,
    }
    return c;
  }

  toAccount(account: AccountResponse): Account {
    return {
      accountCategory: this.normalizeAccountCategoryName(account.accountCategory),
      accountId: account.accountId,
      nickname: account.accountName,
      accountName: account.accountType,
      accountNumber: account.accountNumber,
      accountStatus: account.accountStatus,
      accountValue: account.accountValue,
      hasBrokenLink: account.hasBrokenLink,
      lastUpdated: account.lastUpdated,
      ownerType: account.programName,
      accountCustodian: account.providerName,
      status: account.accountStatus,
      // interest?: number,
      // ugl?: {
      //     value: number; 
      //     percentage: number
      // }
    } as Account
  }

  // TODO: Remove when standardized call is working
  normalizeAccountCategoryName(responseCategory: string | undefined): accountCategory {
    if (!responseCategory) {
      return 'Unknown';
    }
    switch (responseCategory) {
      case 'Investments':
        return 'Investment';
      case 'INVESTMENTS':
      case 'INVESTMENT':
      case 'BANK':
      case 'LOAN':
      case 'REWARD':
      case 'CREDIT CARD':
      case 'External':
      case 'EXTERNAL':
      case 'Linked':
      case 'LINKED': 
          return 'External';
      case 'Liability':
      case 'LIABILITY':
        return 'Liability';
      case 'Asset':
      case 'ASSET':
      case 'Manual':
        return 'Asset';
      case 'Authorized':
      case 'AUTHORIAED':
        return 'Authorized';
      default:
        return 'Unknown';
    }
  }

  getAllocationData(token: string) {
    const url = environment.API_ENDPOINT + '/api/account/v1/experience/accounts/assets?assetView=summary';
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    this.httpService.get<any>(url, {
      headers: headers,
      responseType: "json",
      observe: "body",
    }).pipe(retry(3)).subscribe((response: AllocationResponseData) => {
      this.store.dispatch(LoadedAllocationData({allocationData: this.formatAllocationData(response)}));
    });
  }

  formatAllocationData(data: AllocationResponseData): AllocationData {
    const newObj = {
      externalAssets: data.externalAssets.map(({ allocationValue, assetName, ...rest }) => ({ ['value']: allocationValue, ['name']: assetName, ...rest })),
      internalAssets: data.internalAssets.map(({ allocationValue, assetName, ...rest }) => ({ ['value']: allocationValue, ['name']: assetName, ...rest })),
      portfolioAssets: data.portfolioAssets.map(({ allocationValue, assetName, ...rest }) => ({ ['value']: allocationValue, ['name']: assetName, ...rest })),
    };
    return newObj;
  }
}