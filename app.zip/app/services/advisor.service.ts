import { Injectable } from "@angular/core"
import { Observable, of } from "rxjs";
import { Advisor } from "../models/index.models";
import { HttpClient } from "@angular/common/http";
import { AppState } from "@capacitor/app";
import { Store } from "@ngrx/store";
import { AdvisorResponse, AdvisorsResponse } from "./models/advisors.model";
import { LoadedAdvisorInfo } from "../store/app-store";
import { environment } from "../../environments/environment"

@Injectable({ providedIn: 'root' })
export class AdvisorService {

  constructor(private httpService: HttpClient, private store: Store<AppState>) { };

  getClientAdvisors(token: string) {
    const url = `${environment.API_ENDPOINT}/api/users/v1/experience/user/myadvisors?primary=false&clientAdvisorReq=true&primaryRepReq=false&supportInfo=true`;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    this.httpService.get<AdvisorsResponse>(url, {
      headers: headers,
      responseType: "json",
      observe: "body",
    }).subscribe((response: AdvisorsResponse) => {
      response.advisorData.map( (advisor: AdvisorResponse) => {
        this.store.dispatch(LoadedAdvisorInfo({ advisor: this.fromAdvisorResponse(advisor) }));
      })
    });
    // return this.store.select(getAdvisors);
  }

  fromAdvisorResponse(advisor: AdvisorResponse): Advisor {
    return {
      isPrimary: advisor.primaryFlag,
      advisorId: advisor.advisorId,
      name: {
        first: advisor.firstName,
        last: advisor.lastName,
        initials: `${advisor.firstName.slice(0,1)}${advisor.lastName.slice(0,1)}`,
        full: `${advisor.firstName} ${advisor.middleName} ${advisor.lastName}`,
        preferred: advisor.preferredName,
      },
      phones: [{type: 'Work', number: advisor.officePhoneNumber}],
      email_primary: advisor.emailAddress,
      mailingAddress: advisor.physicalAddress,
    }
  }
}