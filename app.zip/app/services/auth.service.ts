import { Injectable } from "@angular/core";
import { Observable, of, takeUntil } from "rxjs";

// TODO: when validateSSN salt is available
// import * as _sha256 from 'sha256';

import { AuthenticationProfile } from "src/app/models/authentication"
import { SingleAuthMechanismRequest, OtpStartResponse, SecurityResponse, otpMechanism, OtpSuccessResponse, OtpResultBody } from "./models/security.model";
import { AppState, AuthenticatedUser, OpenedAuthentication } from "../store/app-store";
import { Store } from "@ngrx/store";
import { getAuthProfile } from "../store/app-selectors";
import { CFGHttpService } from "./_http.service";
import { ForgotPasswordService } from "./forgot-password.service";
import { Secrets } from "../guards/secrets";
import JSEncrypt from "jsencrypt";

type MethodCallResponse = {
    error?: string,
    data: any
}

@Injectable({ providedIn: 'root' })
export class AuthService {
    httpOptions = {
        headers: {
            'Content-Type': 'application/json',
            'X-CENTRIFY-NATIVE-CLIENT': 'true',
        },
        responseType: "json",
        observe: "body",
    };

    constructor(private http: CFGHttpService, private store: Store<AppState>) { };

    logout() {
        return of(true);
    }

    async invokeLoginAuthentication(userEmail: string, userPassword: string, reason: string): Promise<MethodCallResponse> {
        let authProfile;
        let result: string | null | undefined;
        let otpNeeded: boolean | null | undefined;
        let error: string | void | null | undefined = 'undefined';
        let authBody: OtpResultBody | null | undefined ;
        const url = `/Security/StartAuthentication`;
        const body = {
            "TenantId": "aag0487",
            "User": userEmail,
            "Version": "1.0"
        }
        this.http.POST<any>(url,body,
            {
                'Content-Type': 'application/json',
                'X-CENTRIFY-NATIVE-CLIENT': 'true',
            }
        ).then((res: any) => {
            result = res.Result.Summary;
            if(res.Result.Summary === "LoginSuccess") {
                authBody = res.Result;
            } else {
                authProfile = AuthService.toAuthProfile(res);
            }
        });
        while(authProfile == undefined && authBody == undefined) {
            await new Promise(resolve => setTimeout(resolve,100));
        }
        return {data: {authProfile: authProfile, authBody: authBody, result: result}};
    }
    // TODO: should update to handle errors (username not found, user is not allowed to reset password)
    async applyAuthenticationMechanism(request: SingleAuthMechanismRequest): Promise<MethodCallResponse> {
        let result = false;
        const url = `/Security/AdvanceAuthentication`;
        let foundSsn: boolean | null | undefined;
        let otpNeeded: boolean | null | undefined;
        let error: string | null | undefined;
        this.http.POST<SecurityResponse>(url,request,{
                'Content-Type': 'application/json',
                'X-CENTRIFY-NATIVE-CLIENT': 'true',
        }).then((res: SecurityResponse) => {
            if (res.Result.Auth) {
                let profile = AuthService.toAuthProfile(res);
                this.store.dispatch(OpenedAuthentication({auth: profile}));
            }
            if(request.Action == 'Answer'){
                otpNeeded = this.answerAction(res);
            } else if (request.Action == 'ForgotPassword'){
                foundSsn = ForgotPasswordService.forgotPasswordAction(res.Result.Challenges, false);
            }
            if (error == null || error == undefined) {
                error = 'N/A'
            }
        });

        while(error == null || error == undefined){
            await new Promise(resolve => setTimeout(resolve,100));
        }
        if(error != 'N/A'){
            return {data: null, error: error}
        }
        if(request.Action == 'ForgotPassword'){
            while (foundSsn == null || foundSsn == undefined) {
                await new Promise(resolve => setTimeout(resolve,100));
            }
            return {data: foundSsn}
        } else {
            while (otpNeeded == null || otpNeeded == undefined) {
                await new Promise(resolve => setTimeout(resolve,100));
            }
            return {data: otpNeeded};
        }
    }

    answerAction(res: SecurityResponse): boolean {
        if (res.Result.Summary==="Success") {
            return false;
        } else if (res.Result.Summary==="LoginSuccess") {
            let authToken = res.Result.Auth;
            let userId = res.Result.UserId || ''
            this.store.dispatch(AuthenticatedUser({authToken, userId}))
            return false;
        } else if (res.Result.Summary === "StartNextChallenge") {
            return true;
        }
        return false;
    }

    async requestOTP(num: string): Promise<boolean> {
        let result: boolean | null | undefined;
        const url = `/Security/AdvanceAuthentication`;
        let body = {};
        this.store.select(getAuthProfile).subscribe( (profile) => {
            body = {
                "SessionId": profile.sessionId,
                "MechanismId": profile.otpMechanisms.find((phone => phone.number == num))?.id,
                "Action": "StartOOB"
            }
        });
        this.http.POST<OtpStartResponse>(url,body,{
            'Content-Type': 'application/json',
        }).then((res: OtpStartResponse) => {
            result = (res.Result.Summary==="OobPending");
        });
        while (result == null || result == undefined) {
            await new Promise(resolve => setTimeout(resolve,1000));
        }
        return result;
        // Need to handle timeout somehow?
    }

    async submitOtp(otp: string, num: string, actionType: string): Promise<MethodCallResponse> {
        const url = `/Security/AdvanceAuthentication`;
        let result: boolean | null | undefined;
        let body = {};
        let authBody: OtpResultBody | undefined | null;
        this.store.select(getAuthProfile).subscribe( (profile) => {
            body = {
                "Action": "Answer",
                "Answer": otp,
                "MechanismId": profile.otpMechanisms.find((phone => phone.number == num))?.id,
                "SessionId": profile.sessionId,
            }
        });
        this.http.POST<OtpSuccessResponse>(url,body,{
            'Content-Type': 'application/json',
        }).then((res: OtpSuccessResponse) => {
            if(actionType == 'forgotPassword') {
                result = res.Result.Summary === "NewPackage";
            } else if (actionType == 'loginOtp') {
                authBody = res.Result;
                result = res.Result.Summary === "LoginSuccess";
            }
        });
        while (result == null || result == undefined) {
            await new Promise(resolve => setTimeout(resolve,1000));
        }
        return {data: {result: result, authBody: authBody}};
    }

    async submitSSO(authBody: OtpResultBody, userEncryptPass: string, userName: string): Promise<MethodCallResponse> {
        const url = `/api/user/v1/process/oauth/sso`;
        const body = {
            userName: userName,
            userEncryptPass: userEncryptPass,
            advanceAuthResponse: authBody
        }
        let accessToken: string | undefined | null;
        let lastLogin: string | undefined | null;
        this.http.POST<any>(url,body,{
            'Content-Type': 'application/json',
        }).then((res) => {
            accessToken = res.access_token;
            lastLogin = res.lastLogin;
        });
        while (accessToken == null || accessToken == undefined) {
            await new Promise(resolve => setTimeout(resolve,1000));
        }
        return {data: {token: accessToken, lastLogin: lastLogin}}
    }

    static toAuthProfile(SecurityResponse: SecurityResponse): AuthenticationProfile {
        let passwordMechId;
        let resetMechId;
        let otpMechanisms: otpMechanism[] = [] as otpMechanism[];
        // needs rewrite
        SecurityResponse.Result.Challenges.forEach(challenge => challenge.Mechanisms.forEach(mechanism => {
            if (mechanism.Name == 'UP') {
                passwordMechId = mechanism.MechanismId;
            }
            if (mechanism.Name == 'SMS') {
                otpMechanisms.push({id: mechanism.MechanismId, number: mechanism.PartialDeviceAddress || ''});
            }
            if (mechanism.Name == 'RESET') {
                resetMechId = mechanism.MechanismId;
            }
        }))
        return {
            sessionId: SecurityResponse.Result.SessionId,
            passwordMechanismId: passwordMechId || '',
            otpMechanisms: otpMechanisms,
            resetMechanismId: resetMechId || '',
            allowForgotPassword: SecurityResponse.Result.ClientHints.AllowForgotPassword,
        }
    }

    async validateSSN(ssn: string, username: string): Promise<boolean> {
        const url = `/api/users/v1/experience/user/validateuseridssnid`
        const body = {
            email: username,
            // ssnId: this.encryptSSN(ssn)
            ssnId: ssn
        };
        let isSuccess: boolean | null | undefined;
        this.http.POST<any>(url,body,{
            'Content-Type': 'application/json',
            'X-CENTRIFY-NATIVE-CLIENT': 'true',
        }).then((response) => isSuccess = response.isValid);
        while (isSuccess == null || isSuccess == undefined) {
            await new Promise(resolve => setTimeout(resolve,1000));
        }
        return isSuccess;
    }

    encryptPassword(pass: string): string {
        const pubKey = '-----BEGIN RSA PUBLIC KEY-----' + Secrets.rsaKey + '-----END RSA PUBLIC KEY-----';
        const encrypt = new JSEncrypt();
        encrypt.setPublicKey(pubKey);
        return encrypt.encrypt(pass) || '';
    }

    // private encryptSSN(ssnId: string): string {
    //     const salt = ''
    //     const sha256 = _sha256;
    //     return sha256(ssnId + salt).toUpperCase();
    // }




    // multi way of doing from postman
    // requestOTP(): boolean {
    //     let result = false;
    //     const url = `/Security/AdvanceAuthentication`;
    //     let body = {};
    //     this.store.select(getAuthProfile).subscribe( (profile) => {
    //         body = {
    //             "TenantId": profile.tenantId,
    //             "SessionId": profile.sessionId,
    //             "PersistentLogin": null,
    //             "MultipleOperations": [{
    //                 "MechanismId": profile.otpMechanisms[0],
    //                 "Action": "StartOOB"
    //             }]
    //         }

    //     });
    //     this.httpService.post<OtpStartResponse>(url,body,{
    //         headers: {
    //             'Content-Type': 'application/json',
    //             'X-CENTRIFY-NATIVE-CLIENT': 'true',
    //         },
    //         responseType: "json",
    //         observe: "body",
    //     }).subscribe((res: OtpStartResponse) => {
    //         console.log(res);
    //         result = (res.Result.Summary==="Success");
    //     });
    //     return result;
    // }

    // Start a Username/Password login
    // authenticate(email: string, password: string): Observable<string> {
    //     const authProfile: AuthenticationProfile = this.invokeAuthentication(email);

    //     try {
    //         this.applyAuthenticationMechanism({
    //             Action: 'Answer',
    //             Answer: password,
    //             SessionId: authProfile.sessionId,
    //             MechanismId: authProfile.passwordMechanismId
    //         });
    //         this.requestOTP()
    //     } catch(e) {
            
    //     }

    //     return of('authToken');
    // }
}