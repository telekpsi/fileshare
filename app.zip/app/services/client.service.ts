import { Injectable } from "@angular/core"
import { Store } from "@ngrx/store";
import { Client } from "../models/client";
import { AppState, LoadedUserInfo } from "../store/app-store";
import { ClientResponse } from "./models/client.model";
import { CFGHttpService } from "./_http.service";

@Injectable({ providedIn: 'root' })
export class ClientService {

  constructor(private store: Store<AppState>, private http: CFGHttpService) { };

  getClient(token: string): void {
    const url = '/api/users/v1/experience/user/personalinfo';
    const headers = {'Authorization': `Bearer ${token}`};

    this.http.GET<Client>(url,headers,this.fromClientResponse).then(client => {
      this.store.dispatch(LoadedUserInfo({ client }));
    });
  }

  fromClientResponse(c: ClientResponse): Client {
    return {
      clientId: c.clientExtId?.toString(),
      dob: new Date(c.generalInfo.birthDate),
      name: {
        first: c.generalInfo.firstName,
        last: c.generalInfo.lastName,
        initials: c.generalInfo.firstName.slice(0,1) + c.generalInfo.lastName.slice(0,1),
        full: c.generalInfo.firstName + ' ' + c.generalInfo.lastName,
        preferred: c.generalInfo.preferredName,
      },
      phones: [
        {
          type: "Mobile",
          number: c.contactInfo.cellNumber
        },
        {
          type: "Home",
          number: c.contactInfo.homeNumber
        },
        {
          type: "Work",
          number: c.contactInfo.phoneNumber
        },
      ],
      email_primary: c.contactInfo.primaryEmail,
      email_secondary: c.contactInfo.altEmailAddress,
      mailingAddress: c.addressInfo.mailingAddress,
    } as Client
  }

  getNotificationLabels(token: string) {
    const url = '/api/users/v1/experience/staticData/labels?page_id=notificationMessage';
    const headers = {'Authorization': `Bearer ${token}`};
    this.http.GET<any>(url,headers).then(resp => {
      console.log('inside call');
      console.log(resp.data);
      console.log(resp.data.notificationMessage);
      // store them in store
    });
  }

  getNotifications(token: string) {
    const url = '/integrate-api/notifications/v1/experience/notifications?offset=1&limit=20';
    const headers = {'Authorization': `Bearer ${token}`};
    this.http.GET<Client>(url,headers).then(notification => {
      console.log(notification);
      // this.store.dispatch(LoadedUserInfo({ client }));
    });
  }
}

