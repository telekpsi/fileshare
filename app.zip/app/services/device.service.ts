import { Injectable } from "@angular/core"
import { Storage } from "@ionic/storage"
import { DarkmodeOpts, SettingsState, loadedDarkmode } from "../store/settings-store";
import { Store } from "@ngrx/store";

@Injectable({ providedIn: 'root' })
export class DeviceService {

  constructor(private storage: Storage, private store: Store<SettingsState>) { };

  async loadCredentials(): Promise<string[]> {
    let user = await this.getLocalSetting('cred/username');
    let pass = await this.getLocalSetting('cred/password');
    return [ (!!user) ? user : '', (!!pass) ? pass : ''];
  }

  async storeCredentials(enc_username: string, enc_password: string) {
    return await this.setLocalSetting('cred/username',enc_username) &&
    await this.setLocalSetting('cred/password', enc_password);
  }

  async destroyStoredCredentials() {
    await this.remove('cred/username');
    await this.remove('cred/password');
    return (await this.loadCredentials()).length == 0

  }

  async setDarkmode(v: DarkmodeOpts) {
    this.store.dispatch(loadedDarkmode({darkmode:v}))
    return await this.setLocalSetting('darkmode', v);
  }
  
  async getDarkmode(): Promise<DarkmodeOpts> {
    return await this.getLocalSetting('darkmode') as DarkmodeOpts;
  }

  async setLocalSetting(setting: string, value: any) {
    if (typeof(value) == Object.prototype) {
        value = JSON.stringify(value);
    }
    return await this.set(setting, value);
  }

  async getLocalSetting(setting: string) {
    let value = await this.get(setting);
    if (value && value.toString().split(':').length > 1) {
        value = JSON.parse(value);
    }
    return value;
  }

  // from @Ionic/storage
  private async set(key: string, value: string): Promise<boolean> {
    try {
        return await this.storage.set(key, value);
    } catch (e) {
        console.log(e);
        return false;
    }
  }

  // from @Ionic/storage
  private async get(key: string): Promise<string | null> {
    try {
        return await this.storage.get(key);
    } catch (e) {
        console.log(e);
        return null;
    }
  }

  private async remove(key: string): Promise<string | null> {
    try {
        return await this.storage.remove(key);
    } catch (e) {
        console.log(e);
        return null;
    }
  }


}