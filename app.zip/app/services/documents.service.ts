import { Injectable } from "@angular/core"
import { Store } from "@ngrx/store";
import { AppState } from "../store/app-store";
import { CFGHttpService } from "./_http.service";
import { getAuthToken } from "../store/app-selectors";
import { BoxGetFolderResponse } from "./models/documents.model";
import { BoxItem } from "../models/documents.model";
import { Subject, takeUntil } from "rxjs";

@Injectable({ providedIn: 'root' })
export class DocumentsService {
    private readonly destroyed$ = new Subject()

    boxHeaders = { 
        "Authorization": "[ACCESS_TOKEN]",
        "Content-Type": "application/json"
    }

    constructor(private http: CFGHttpService, private store: Store<AppState>) {
        this.store.select(getAuthToken).pipe(takeUntil(this.destroyed$)).subscribe(t => this.boxHeaders.Authorization = "Bearer "+t);
    }

    async getDocumentsFolder(folderId: string): Promise<BoxItem[]> {
        const url = `/integrate-api/document/v1/experience/document/folder/${folderId}/items?sortBy=name&order=asc&page=1&hirarchyLvl=1`

        const unwrap = (r: BoxGetFolderResponse): BoxItem[] => {
            return r.entries;
        }
        const res = await this.http.GET<BoxItem[]>(url,this.boxHeaders,unwrap);
        while (!res) {
            await new Promise(resolve => setTimeout(resolve,100));
        }
        return res;
    }
}