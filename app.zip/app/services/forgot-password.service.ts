import { Injectable } from '@angular/core';
import { AuthenticationProfile } from '../models/authentication';
import { OtpStartResponse, SecurityMechanism, SecurityResponse } from './models/security.model';
import { AuthService } from './auth.service';
import { Store } from '@ngrx/store';
import { CFGHttpService } from './_http.service';
import { HttpClient } from '@angular/common/http';
import { AppState } from '../store/app-store';
import { getAuthProfile } from '../store/app-selectors';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  constructor(
    private httpService: HttpClient,
    private http: CFGHttpService,
    private store: Store<AppState>
  ) { }

  async invokeForgotAuthentication (userEmail: string, reason: string): Promise<AuthenticationProfile>{
    let authProfile;
    const url = `/Security/StartAuthentication`;
    const body = {
        "TenantId": "aag0487",
        "User": userEmail,
        "Version": "1.0"
    }
    this.http.POST<SecurityResponse>(url,body,
        {
            'Content-Type': 'application/json',
            'X-CENTRIFY-NATIVE-CLIENT': 'true',
        }
    ).then((res: SecurityResponse) => {
        authProfile = AuthService.toAuthProfile(res);
    });
    while (!authProfile) {
        await new Promise(resolve => setTimeout(resolve,100));
    }
    return authProfile;
  }

  static forgotPasswordAction(challenges: {Mechanisms: SecurityMechanism[]}[], foundSsn: boolean): boolean {
    challenges.forEach(challenge => challenge.Mechanisms.forEach(mechanism => {
        if (mechanism.Name == 'SQ') {
            foundSsn = true
        }
    }));
    // function taking in 
    foundSsn = foundSsn == true ? foundSsn : false;
    return foundSsn;
  }

  async resetPassword(password: string): Promise<boolean> {
      const url = `/Security/AdvanceAuthentication`;
      let result: boolean | null | undefined;
      let body = {};
      this.store.select(getAuthProfile).subscribe( (profile) => {
          body = {
              "Action": "Answer",
              "Answer": password,
              "MechanismId": profile.resetMechanismId,
              "SessionId": profile.sessionId,
          }
      });
      this.http.POST<OtpStartResponse>(url,body,{
          'Content-Type': 'application/json',
      }).then((res: OtpStartResponse) => {
          result = (res.Result.Summary==="NoncommitalSuccess");
      });
      while (result == null || result == undefined) {
          await new Promise(resolve => setTimeout(resolve,1000));
      }
      return result;
  }

  async validateSSN(ssn: string, username: string): Promise<boolean> {
      const url = `/api/users/v1/experience/user/validateuseridssnid`
      const body = {
          email: username,
          // ssnId: this.encryptSSN(ssn)
          ssnId: ssn
      };
      let isSuccess: boolean | null | undefined;
      this.http.POST<any>(url,body,{
          'Content-Type': 'application/json',
          'X-CENTRIFY-NATIVE-CLIENT': 'true',
      }).then((response) => isSuccess = response.isValid);
      while (isSuccess == null || isSuccess == undefined) {
          await new Promise(resolve => setTimeout(resolve,1000));
      }
      return isSuccess;
  }

  // private encryptSSN(ssnId: string): string {
  //     const salt = ''
  //     const sha256 = _sha256;
  //     return sha256(ssnId + salt).toUpperCase();
  // }
}
