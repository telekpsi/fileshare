import { Injectable } from "@angular/core"
import { HttpClient } from "@angular/common/http";
import { Store } from "@ngrx/store"
import { retry } from "rxjs";

import { AppState } from "../store/app-store";
import { IndividualHoldingsResponse, TransactionResponse, TransactionResponseOuter } from "./models/holdings-transactions.model";
import { environment } from "../../environments/environment"
import { CFGHttpService } from "./_http.service";

@Injectable({
  providedIn: 'root'
})
export class HoldingsTransactionsService {

  constructor(private store: Store<AppState>, private httpService: CFGHttpService) {};

  async getSpecificAccountTransactions(token: string, accountId: string): Promise<TransactionResponseOuter> {
    const url = `/api/account/v1/experience/transactions?accountId=${accountId}`;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    const body = {
      "limit": 25,
      "offset": 0,
      "order": "desc",
      "sortBy": "tradeDate",
      "symbol": "",
      "timePeriod": "05/20/2022"
    }
    let data: TransactionResponse[] = [];
    return this.httpService.POST<TransactionResponseOuter>(url, body, headers);

  }

  // async getAllAccountHoldings(token: string) {
  //   const url = `${environment.API_ENDPOINT}/api/account/v1/experience/accounts/holdings?sortBy=totalValue&order=desc`;
  //   const headers = {
  //     'Content-Type': 'application/json',
  //     'Authorization': `Bearer ${token}`,
  //   };
  //   this.httpService.GET<any>(url, {
  //     headers: headers,
  //     responseType: "json",
  //     observe: "body",
  //   }).pipe(retry(3)).subscribe(response => {
  //     console.log(response);
  //   });
  // }

  async getSpecificAccountHoldings(token: string, accountId: string): Promise<IndividualHoldingsResponse> {
    const url = `/api/account/v1/experience/accounts/11636113/holdings?sortBy=totalValue&order=desc&accountType=internal`;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    let data: IndividualHoldingsResponse = {} as IndividualHoldingsResponse;
    return this.httpService.GET<IndividualHoldingsResponse>(url, headers);
  }
}
