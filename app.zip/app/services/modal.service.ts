import { Injectable } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { enterModalTopToBottomAnimation, leaveModalBottomToTopAnimation } from '../shared/animations/enterModalTopToBottom';
import { enterModalLeftToRightDrawerAnimation, leaveModalRightToLeftDrawerAnimation } from '../shared/animations/enterModalLeftToRightDrawer';
import { AppMenuComponent } from '../shared/app-menu/app-menu.component';
import { UserMenuComponent } from '../shared/user-menu/user-menu.component';
import { LinkAccountComponent } from '../pages/accounts/link-account/link-account.component';
import { ActionsPulloutMenuComponent } from '../shared/actions-pullout-menu/actions-pullout-menu.component';
import { enterActionSheetModalBottomToTop, leaveActionSheetModalTopToBottomAnimation } from '../shared/animations/enterActionSheetModalBottomToTop';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  private _menu: string = 'none';
  private _action: string = '';
  private _error: string = '';
  
  public get menu() : string {
    return this._menu;
  }
  
  public set menu(value : string) {
    this._menu = value;
  }

  public get action() : string {
    return this._action;
  }

  public get error() : string {
    return this._error;
  }
  
  constructor(private modalCtrl: ModalController) { }

  async toggleMenu() {
    if (this._menu == 'none') { 
      this.modalCtrl.dismiss();
      this._menu = 'none';
    }
    else {
      let modalComponent = this._menu == 'settings' ? AppMenuComponent : UserMenuComponent;
      const modal = await this.modalCtrl.create({
        component: modalComponent,
        cssClass: 'bounded-by-headerfooter-drawer-modal',
        enterAnimation: enterModalLeftToRightDrawerAnimation,
        leaveAnimation: leaveModalRightToLeftDrawerAnimation,
        // showBackdrop: false,
        backdropDismiss: true,
      });
      modal.present();
  
      const { data, role } = await modal.onWillDismiss();
      if (role) {
        this._menu = 'none';
      }
    }
  }

  async createLinkModal() {
    const modal = await this.modalCtrl.create({
      component: LinkAccountComponent,
      cssClass: 'bounded-by-screensize-modal',
      backdropDismiss: true,
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();
    if (role) {
      this._menu = 'none';
    }
  }

  async createDocumentActionsModal(percentage: number, options: {icon: string;label: string;}[]) {
    const modal = await this.modalCtrl.create({
      component: ActionsPulloutMenuComponent,
      backdropDismiss: true,
      cssClass: 'action-sheet-modal',
      initialBreakpoint: percentage,
      breakpoints: [percentage],
      componentProps: {
        actions: options,
      },
    });
    modal.present();
    return await modal.onWillDismiss();
  }
}
