export type AccountsResponse = {
    totalAccountsValue: number,
    accountsByCategory: [
        
    ],
    isInternal: boolean
}

export type AccountCategoryResponse = {
    category: string,
    totalAccountCategoryValue: number,
    accounts: AccountResponse[],
};

export type AccountResponse = {
    accountCategory?: string,
    accountId: string,
    accountLabel?: string,
    accountName?: string,
    accountNumber?: string,
    accountStatus: string,
    accountType: string,
    accountValue: number,
    brokerDealerType?: string,
    hasBrokenLink?: boolean,
    hasLinkedBankAccount: boolean,
    isRia: boolean,
    lastUpdated: string,
    pershingAPIResponse: boolean,
    programName?: string,
    providerName?: string,
}