export type AdvisorsResponse = {
    advisorData: AdvisorResponse[],
    techSupport: {},
}

export type AdvisorResponse = {
    advisorId: number,
    crdNumber: string,
    emailAddress: string,
    firstName: string,
    lastName: string,
    middleName: string,
    officePhoneNumber: string,
    personTitle: string,
    physicalAddress: {
        addressLine1: string,
        addressLine2: string,
        city: string,
        country: string,
        state: string,
        zip: string,
    }
    preferredName: string,
    primaryFlag: boolean,
    status: boolean,
}

/*
export type AdvisorResponse = {
    advisorId: 43440
    crdNumber: "3083238"
    emailAddress: "mtash@ceteratest.com"
    firstName: "Michael"
    lastName: "TASH"
    middleName: "A"
    officePhoneNumber: "8566529911"
    personTitle: "Rep"
    physicalAddress: {
        addressLine1: "213 White Horse Pike"
        addressLine2: ""
        city: "Haddon Heights"
        country: "United States"
        state: "NJ"
        zip: "08035"
    }
    preferredName: ""
    primaryFlag: true
    status: true
}
*/