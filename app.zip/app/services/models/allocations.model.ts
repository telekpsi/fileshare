export type AllocationResponseData = {
    externalAssets: AllocationResponseCategoryData[],
    internalAssets: AllocationResponseCategoryData[],
    portfolioAssets: AllocationResponseCategoryData[]
};

export type AllocationResponseCategoryData = {
    allocationPercentage: number,
    allocationValue: number,
    amountLabel: string,
    assetColorCode: string,
    assetName: string
}