export type ClientResponse = {
    addressInfo: {
        attention: string,
        homeAddress: string,
        homeStateCode: string,
        mailingAddress: string
    }
    applicationState: string,
    bdExtId: number,
    brokerDealerType: string,
    clientExtId: number,
    clientSince: string,
    clientStatus: string,
    clientType: string,
    contactInfo:  {
        altEmailAddress: string,
        cellNumber: string,
        homeNumber: string,
        otherEmail: string,
        phoneNumber: string,
        primaryEmail: string,
    }
    enableInvite: boolean,
    familyDetails: {
        hasSharedAccess: boolean,
        id: number,
        name: string,
        shareAccessStatus: string,
        sharingAccessStarted: boolean
    }
    generalInfo: { 
        age?: string | number,
        birthDate: string,
        countryOfCitizenship: string,
        firstName: string,
        gender: string,
        lastName: string,
        middleName: string,
        preferredName?: string,
        prefix?: string,
        ssn?: string,
        suffix?: string
    }
    hasPersonalEnrollment: boolean,
    isClient: boolean,
    isRegistered: boolean,
    isRiaCISClient: boolean,
    isStateWithholding: boolean,
    profileUpdatedDetails: {
        hasRegisteredAccounts: boolean
    }
    registeredDate: string,
    userAccessInfo: { 
        isRevoked: boolean,
        accessStatus: string,
        isEmailSame: boolean
    }
}

// addressInfo: {
//     attention: "ALAN NGUYEN"
//     homeAddress: "13 Manor Ave<br> Claymont, DE 19703-3304 <br>United States"
//     homeStateCode: "DE"
//     mailingAddress: "13 Manor Ave<br> Claymont, DE 19703 <br>United States"
// }
// applicationState: null
// bdExtId: 1
// brokerDealerType: "CAN"
// clientExtId: 9050486
// clientSince: "01/06/2014"
// clientStatus: "Active"
// clientType: "Person"
// contactInfo:  {
//     altEmailAddress: "ALAN.DMD1@CETERATEST.COM"
//     cellNumber: "3642010522"
//     homeNumber: "2673037274"
//     otherEmail: "ALAN.DMD1@CETERATEST.COM"
//     phoneNumber: "2673037274"
//     primaryEmail: "ALAN.DMD@CETERATEST.COM"
// }
// enableInvite: false
// familyDetails: {
//     hasSharedAccess: false
//     id: 380
//     name: "Nguyen Fam"
//     shareAccessStatus: "CAN_SHARE"
//     sharingAccessStarted: false
// }
// generalInfo: { 
//     age: null
//     birthDate: "05/06/1975"
//     countryOfCitizenship: "US"
//     firstName: "ALAN"
//     gender: "MALE"
//     lastName: "NGUYEN"
//     middleName: "S"
//     preferredName: null
//     prefix: null
//     ssn: "208680566"
//     suffix: null
// }
// hasPersonalEnrollment: true
// isClient: true
// isRegistered: true
// isRiaCISClient: false
// isStateWithholding: true
// profileUpdatedDetails: {
//     hasRegisteredAccounts: true
// }
// registeredDate: "04/28/2023"
// userAccessInfo: { 
//     isRevoked: false,
//     accessStatus: "ENABLED",
//     isEmailSame: false 
// }