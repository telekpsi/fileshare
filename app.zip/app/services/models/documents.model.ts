import { BoxItem } from "src/app/models/documents.model"

export type BoxGetFolderResponse = {
    entries: BoxItem[]
}