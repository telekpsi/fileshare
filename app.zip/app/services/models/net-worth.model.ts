export type NetWorthResponseData = {
    category: string,
    values: NetWorthResponseInnerData[]
}

export type NetWorthResponseInnerData = {
    date: 'string',
    sumAsset: number,
    sumLiability: number
}