export type SecurityResponse = {
    success: boolean,
    Result: {
        Auth: string,
        UserId?: string,
        ClientHints: {
            PersistDefault: boolean,
            AllowPersist: boolean,
            AllowForgotPassword: boolean,
            EndpointAuthenticationEnabled: boolean,
        },
        Version: string,
        SessionId: string,
        Challenges: {Mechanisms: SecurityMechanism[]}[]
        Summary: string,
    },
    Message?: string
}

export type otpMechanism = {id: string, number: string};

export type SecurityMechanism = {
    AnswerType: string,
    Name: string,
    PromptMechChosen: string,
    PromptSelectMech: string,
    MechanismId: string,
    Enrolled: boolean,
    PartialDeviceAddress?: string,
}

export type OtpStartResponse = {
    success: boolean,
    Result: {
        Auth?: string,
        ResultAppliesTo?: string,
        Summary: string,
    },
}

export interface OtpSuccessResponse extends OtpStartResponse {
    Result: OtpResultBody
}

export type OtpResultBody = {
    Auth?: string,
    AuthLevel: string,
    CustomerID: string,
    DisplayName: string,
    EmailAddress: string,
    PodFqdn: string,
    ResultAppliesTo?: string,
    SourceDsType: string,
    Summary: string,
    SystemID: string,
    User: string,
    UserDirectory: string,
    UserId: string
}

export type AuthMechanismResponse = {
    success: boolean,
    Result: {
        Auth: string,
        UserId?: string,
        Summary: string,
        Challenges: [{
            Mechanisms: [{
                Name: string,
                MechanismId: string
            }]
        }]
    },
}

// export type MultipleAuthMechanismRequest = {
//     TenantId: string,
//     SessionId: string,
//     PersistentLogin: null,
//     MultipleOperations: {
//         MechanismId: string,
//         Answer: string,
//         Action: "Answer",
//     }[]
// }

export type SingleAuthMechanismRequest = {
    Action: string,
    Answer?: string,
    MechanismId?: string,
    SessionId: string
}