import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppState } from '@capacitor/app';
import { Store } from '@ngrx/store';
import { DateTimeData, DateTimeSeries } from '../models/index.models';
import { LoadedNetWorthData, LoadedNetWorthHighlights } from '../store/app-store';
import { NetWorthResponseData, NetWorthResponseInnerData } from './models/net-worth.model';
import { environment } from "../../environments/environment"
import { CFGHttpService } from './_http.service';

const UNIXDAY = 86400000;
@Injectable({
  providedIn: 'root'
})
export class NetWorthService {

  constructor(private store: Store<AppState>, private httpService: HttpClient, private http: CFGHttpService) { }

  getNetWorthHistory(user: string) {
    const url = '/integrate-api/account/history/v1/process/getnetworth';
    const headers = {
      'Content-Type': 'application/json',
      // nononononononononononononononononononononononononononono
      'Client_id': 'e80842489b084fda94cd1f5789b977bd',
      // TODO: please let us fix this at some point
      'Client_secret': '641cACd1aa8f4a688D8f7Df38CF4b509'
    };
    const body = {
      // need to find out where clientId comes from, since this is lookup id
      "clientId": 53755859,
      "brokerDealerId": 1,
    }
    this.http.POST<DateTimeSeries[]>(url,body,headers,NetWorthService.formatNetWorthHistoryData).then(data => {
      this.store.dispatch(LoadedNetWorthData({data}));
    });
    // this.httpService.post<any>(url, body, {
    //   headers: headers,
    //   responseType: "json",
    //   observe: "body",
    // }).subscribe(response => {
    //   this.store.dispatch(LoadedNetWorthData({data: this.formatNetWorthHistoryData(response)}))
    // });
    // return this.store.select(getNetWorthData);
  }

  getNetWorthHighlights(token: string) {
    const url = `/api/account/v1/experience/accounts/networth`;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
    this.http.GET<any>(url, headers).then(response => {
      this.store.dispatch(LoadedNetWorthHighlights({netWorthHighlights: response}));
    });
  }

  static formatNetWorthHistoryData(data: NetWorthResponseData[]): DateTimeSeries[] {
    return data.map((entry) => { return {
        name: NetWorthService.getNetWorthCategory(entry.category),
        data: NetWorthService.gapfillSeriesData(entry.values),
    }});
  }

  static gapfillSeriesData(data: NetWorthResponseInnerData[]): DateTimeData[] {
    let series: DateTimeData[] = [];
    let lastDate = new Date(0);
    let lastVal = 0;
    data.forEach(datum => {
      let thisDate = new Date(datum.date);
      while (lastDate.getTime() > 0 && (thisDate.getTime() > lastDate.getTime()+UNIXDAY)) {
        let gapDate = new Date(lastDate.getTime()+UNIXDAY);
        series.push({date: NetWorthService.toEchartsDate(gapDate), value:lastVal});
        lastDate = gapDate;
      }
      let thisVal = (datum.sumAsset-datum.sumLiability);
      series.push({date: NetWorthService.toEchartsDate(thisDate), value:thisVal});
      lastDate = thisDate;
      lastVal = thisVal;
    });
    return series;
  }
  
  static toEchartsDate(dateObj: Date): string {
    return `${dateObj.getFullYear()}-${dateObj.getMonth()}-${dateObj.getDate()}T${dateObj.getHours()}:${dateObj.getMinutes()}:${dateObj.getSeconds()+'.000'}Z`
  }

  static getNetWorthCategory(cat: string): string {
    switch (cat) {
      case '1': {
        return 'Internal'
      }
      case '2': {
        return 'Authorized'
      }
      case '3': {
        return 'Linked'
      }
      case '4': {
        return 'Manual'
      }
      default: {
        return 'Internal'
      }
    }
  }
}
