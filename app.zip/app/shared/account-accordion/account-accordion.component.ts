import { Component, Input, OnInit } from '@angular/core';
import { accountCategory } from 'src/app/models/account.model';
import { AccountsCategory } from 'src/app/models/index.models';

@Component({
  selector: 'app-account-accordion',
  templateUrl: './account-accordion.component.html',
  styleUrls: ['./account-accordion.component.scss'],
})
export class AccountAccordionComponent  implements OnInit {
  
  @Input() isOpen: boolean = false;
  @Input() parent: string = '';
  @Input() accordion!: AccountsCategory;
  accordionOpen = false;
  metadata: any;

  constructor() { }

  ngOnInit() {
    this.metadata = this.meta(this.accordion.accountCategory)
    if (this.isOpen) {
      this.accordionOpen = true;
    }
  }

  toggleAccordion() {
    this.accordionOpen = !this.accordionOpen;
  }

  meta(category: accountCategory) {
    switch(category) {
      case 'Investment':
        return {title: 'Investment Accounts',
        tooltip: 'Investment accounts consist of Cetera and directly held accounts.',
        }
      case 'Asset':
        return {title: 'Manually Added Assets & Liabilities',
        tooltip: 'Stuff about Manually Added Assets',}
      case 'Liability':
      case 'External':
        return {title: 'Linked Assets & Liabilities',
        tooltip: 'Linked account information is updated with the last retrieved data from the account provider\'s website and may vary by provider.',
        }
      case 'Authorized':
        return {title: 'Authorized Accounts',
        tooltip: 'Stuff about Authorized Assets',}
      case 'Unknown':
        return {}
    }
  }


}
