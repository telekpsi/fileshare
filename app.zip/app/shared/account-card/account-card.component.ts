import { Component, Input, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Account } from 'src/app/models/index.models';
import { AccountsService } from 'src/app/services/accounts.service';
import { HoldingsTransactionsService } from 'src/app/services/holdings-transactions.service';
import { getAuthToken } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';

@Component({
  selector: 'app-account-card',
  templateUrl: './account-card.component.html',
  styleUrls: ['./account-card.component.scss'],
})
export class AccountCardComponent  implements OnInit {
  @Input() account!: Account;
  @Input() parent: string = '';
  private readonly destroyed$ = new Subject();

  constructor(private accountsService: AccountsService, private holdingsService: HoldingsTransactionsService, private store: Store<AppState>, private alert: AlertController) { }

  ngOnInit() {}

  async openAccount() {
    this.store.select(getAuthToken).pipe(takeUntil(this.destroyed$)).subscribe(async (token)=>{
      if (token == '') {return}
      const holdings = await this.holdingsService.getSpecificAccountHoldings(token,this.account.accountId);
      const transactions = (await this.holdingsService.getSpecificAccountTransactions(token,this.account.accountId)).data;
      let transactionsText = transactions.map(t => `${t.transactionType} on ${t.tradeDate}`);
      const alert = await this.alert.create({
        header: this.account.accountName,
        subHeader: `as of ${this.account.lastUpdated || 'Today'}`,
        message: `Transactions:\n${transactionsText.join('\n')}\n\nHoldings:\n`, //${holdingsText.join('\n')}
        buttons: ['Thanks!'],
      });
      await alert.present();
    });
  }

}
