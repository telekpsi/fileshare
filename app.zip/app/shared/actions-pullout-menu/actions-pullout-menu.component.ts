import { Component, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-actions-pullout-menu',
  templateUrl: './actions-pullout-menu.component.html',
  styleUrls: ['./actions-pullout-menu.component.scss'],
})
export class ActionsPulloutMenuComponent {
  @Input() title?: string;
  @Input() actions!: {
    icon: string,
    label: string,
  }[];

  constructor(private controller: ModalController) {}

  actionSelected(action: string) {
    this.controller.dismiss(action);
  }

  cancel() {
    this.controller.dismiss('cancel','cancel');
  }

}
