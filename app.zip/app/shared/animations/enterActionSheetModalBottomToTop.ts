import { AnimationController } from "@ionic/angular";

const animationCtrl: AnimationController = new AnimationController;

let modalPercent: number = 0;


// is there a way to pass in the ion-content instead as the baseEl?
export const enterActionSheetModalBottomToTop = (baseEl: any, percent: number) => {
    const root = baseEl.shadowRoot;
    modalPercent = percent;

    const backdropAnimation = animationCtrl.create()
      .addElement(root.querySelector('ion-backdrop')!)
      .fromTo('opacity', '0.01', 'var(--backdrop-opacity)');

    const wrapperAnimation = animationCtrl.create()
      .addElement(root.querySelector('.modal-wrapper')!)
      .keyframes([
        { offset: 0, opacity: '0', transform: `translateY(0%)` },
        { offset: 1, opacity: '0.99', transform: `translateY(-${modalPercent}%)` }
      ]);

    return animationCtrl.create()
      .addElement(baseEl)
      .easing('ease-out')
      .duration(300)
      .addAnimation([backdropAnimation, wrapperAnimation]);
  }

export const leaveActionSheetModalTopToBottomAnimation = (baseEl: any) => {
    return enterActionSheetModalBottomToTop(baseEl, modalPercent).direction('reverse');
}