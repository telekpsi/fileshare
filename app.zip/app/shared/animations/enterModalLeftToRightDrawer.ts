import { AnimationController } from "@ionic/angular";

const animationCtrl: AnimationController = new AnimationController;

// is there a way to pass in the ion-content instead as the baseEl?
export const enterModalLeftToRightDrawerAnimation = (baseEl: any) => {
    console.log(baseEl);
    const root = baseEl.shadowRoot;

    const backdropAnimation = animationCtrl.create()
      .addElement(root.querySelector('ion-backdrop')!)
      .fromTo('opacity', '0.01', 'var(--backdrop-opacity)');

    const wrapperAnimation = animationCtrl.create()
      .addElement(root.querySelector('.modal-wrapper')!)
      .keyframes([
        { offset: 0, opacity: '0', transform: 'translateX(-100%)' },
        { offset: 1, opacity: '0.99', transform: 'translateX(0%)' }
      ]);

    return animationCtrl.create()
      .addElement(baseEl)
      .easing('ease-out')
      .duration(600)
      .addAnimation([backdropAnimation, wrapperAnimation]);
  }

export const leaveModalRightToLeftDrawerAnimation = (baseEl: any) => {
    return enterModalLeftToRightDrawerAnimation(baseEl).direction('reverse');
}