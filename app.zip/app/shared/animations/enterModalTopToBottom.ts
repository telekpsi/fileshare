import { AnimationController } from "@ionic/angular";

const animationCtrl: AnimationController = new AnimationController;

// is there a way to pass in the ion-content instead as the baseEl?
export const enterModalTopToBottomAnimation = (baseEl: any) => {
    const root = baseEl.shadowRoot;

    const backdropAnimation = animationCtrl.create()
      .addElement(root.querySelector('ion-backdrop')!)
      .fromTo('opacity', '0.01', 'var(--backdrop-opacity)');

    const wrapperAnimation = animationCtrl.create()
      .addElement(root.querySelector('.modal-wrapper')!)
      .keyframes([
        { offset: 0, opacity: '0', transform: 'translateY(-100%)' },
        { offset: 1, opacity: '0.99', transform: 'translateY(0%)' }
      ]);

    return animationCtrl.create()
      .addElement(baseEl)
      .easing('ease-out')
      .duration(600)
      .addAnimation([backdropAnimation, wrapperAnimation]);
  }

export const leaveModalBottomToTopAnimation = (baseEl: any) => {
    return enterModalTopToBottomAnimation(baseEl).direction('reverse');
}