import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { Client } from 'src/app/models/index.models';
import { ModalService } from 'src/app/services/modal.service';
import { getClient } from 'src/app/store/app-selectors';
import { AppState, UserLoggedOut } from 'src/app/store/app-store';
import { SettingsState } from 'src/app/store/settings-store';

@Component({
  selector: 'app-menu',
  templateUrl: './app-menu.component.html',
  styleUrls: ['./app-menu.component.scss'],
})
export class AppMenuComponent implements OnInit {
  headerTitle: string = '';
  client$: Observable<Client>;
  // deviceMode: DarkmodeOpts = 'device';

  current_tab = "dashboard";
  public appPages = [
    { title: 'Home', url: 'dashboard', icon: 'home', tab: 'dashboard' },
    { title: 'Accounts', url: 'accounts', icon: 'wallet', tab: 'accounts' },
    { title: 'Documents', url: 'documents', icon: 'document-text', tab: 'documents' },
    { title: 'Financial Prof.', url: 'advisors', icon: 'person-circle', tab: 'advisors' },
  ];

  constructor(
    private store: Store<AppState & SettingsState>,
    private modalService: ModalService,
    // private device: DeviceService,
    private router: Router,
  ) {
    this.client$ = this.store.select(getClient);
  }

  ngOnInit() {
    // this.store.select(getDarkmodeSetting).subscribe(( darkmode => {
    //   this.deviceMode = darkmode.mode
    // }));
  }

  // segmentChanged(event: any) {
  //   this.device.setDarkmode(event.detail.value);
  //   console.log(event.detail.value);
  // }

  onLogout() {
    this.onCloseModal();
    this.store.dispatch(UserLoggedOut());
  }

  onCloseModal() {
    this.modalService.menu='none';
    this.modalService.toggleMenu();
  }

  openUserMenu() {
    // this.modalService.menu = 'user';
    // this.modalService.toggleMenu();
    this.onCloseModal();
    this.router.navigate(['aw/user-menu']);
  }

  openAccountSettings() {
    this.onCloseModal();
    this.router.navigate(['aw/account-settings']);
  }
}
