import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-error-banner',
  template: `
  <ion-item *ngIf="!!error" lines="none" fill="outline" color="{{error.type == 'error' ? 'danger' : 'warning'}}" mode="md">
    <div class="alert-error-icon-parent">
      <ion-icon slot="start" name="alert-circle" [ngClass]="error.type == 'error' ? 'alert-error-icon' : 'alert-warning-icon'"></ion-icon>
    </div>
    <ion-label *ngIf="error.title" class="banner-error-text">{{ error.title }}</ion-label>
    <ion-text class="banner-error-text">{{ error.body }}</ion-text>
  </ion-item>
  `,
  styleUrls: ['./error-banner.component.scss'],
})
export class ErrorBannerComponent {
  @Input() error!: {
    title?: string,
    body: string,
    type: 'error' | 'warning',
  } | undefined

}
