import { EventEmitter, Directive, OnInit, Output, Input, ElementRef } from '@angular/core';
import { timer, Subscription } from 'rxjs';

@Directive({
  selector: '[gesture]'
})
export class GestureDirective implements OnInit {

  timerSub!: Subscription;
  pointerEvent?: PointerEvent;

  @Input() delay!: number;
  @Output() onHold: EventEmitter<any> = new EventEmitter();
  @Output() onClick: EventEmitter<any> = new EventEmitter();

  constructor(
    private elementRef: ElementRef<HTMLElement>
  ) { }

  ngOnInit() {
    const isTouch = ('ontouchstart' in document.documentElement);
    const element = this.elementRef.nativeElement;
    // pointer event start
    element.onpointerdown = (ev) => this.pressed(ev);
    // pointer event cancel(s)
    element.onpointerup = () => { this.released(); };
    element.onpointercancel = () => { this.canceled(); };
    if (isTouch) {
      element.onpointerleave = () => { this.canceled(); };
    }
  }

  private pressed(pointerEvent: PointerEvent) {
    this.pointerEvent = pointerEvent;
    this.timerSub = timer(this.delay).subscribe(() => {
      this.onHold.emit(pointerEvent);
    });
  }

  private released() {
    if (this.timerSub && !this.timerSub.closed) {
      this.onClick.emit(this.pointerEvent);
      this.timerSub.unsubscribe();
    }
  }

  private canceled() {
    if (this.timerSub && !this.timerSub.closed) {
      this.timerSub.unsubscribe();
    }
  }

}