import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, Event } from '@angular/router';
import { AppState } from '@capacitor/app';
import { MenuController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Client } from 'src/app/models/index.models';
import { ModalService } from 'src/app/services/modal.service';
import { getClient } from 'src/app/store/app-selectors';

@Component({
  selector: 'app-header-bar',
  templateUrl: './header-bar.component.html',
  styleUrls: ['./header-bar.component.scss'],
})
export class HeaderBarComponent  implements OnInit {
  headerTitle: string = '';
  private destroy$ = new Subject();
  client!: Client;
  menu: string = '';
  
  public appPages = [
    { title: 'Home', url: '/aw/dashboard', icon: 'home', tab: 'dashboard' },
    { title: 'Accounts', url: '/aw/accounts', icon: 'wallet', tab: 'accounts' },
    { title: 'Documents', url: '/aw/documents', icon: 'document-text', tab: 'documents' },
    { title: 'Financial Prof.', url: '/aw/advisors', icon: 'people', tab: 'advisors' },
  ];

  constructor(private store: Store<AppState>, private router: Router, private modalService: ModalService) {
    this.store.select(getClient).pipe(takeUntil(this.destroy$)).subscribe(c => this.client = c);
  }

  titleFromUrl(routeUrl: string): string {
    const urlArray = routeUrl.split('/');
    return this.appPages.find(p => urlArray.includes(p.tab))?.title || 'AdviceWorks';
  }

  ngOnInit() {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        this.headerTitle = this.titleFromUrl(event.url);
      }
    })
  }

  menuClicked(clickedMenu: string) {
    this.modalService.menu = this.modalService.menu == clickedMenu ? 'none' : clickedMenu;
    this.modalService.toggleMenu();
  }

  notificationsClicked() {
    this.router.navigate(['aw/notifications']);
  }
}
