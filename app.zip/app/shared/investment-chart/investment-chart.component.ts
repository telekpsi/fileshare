import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { PieSeriesOption, TitleComponentOption } from 'echarts';
import { EChartsOption } from 'echarts/types/dist/echarts';
import { Subject, takeUntil } from 'rxjs';
import { AllocationData, AllocationCategoryData } from 'src/app/models/index.models';
import { getAssetAllocation } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';

@Component({
  selector: 'app-investment-chart',
  templateUrl: './investment-chart.component.html',
  styleUrls: ['./investment-chart.component.scss'],
})
export class InvestmentChartComponent implements OnInit {
  @Input() allocationType: string = '';
  colors: string[] = [
    '#462321',
    '#6b291d',
    '#b8471a',
    '#ea7d2a',
    '#ffb732',
    '#ffda45',
    '#fcf760',
    '#8bd155',
    '#3e9f49',
    '#237350',
    '#245756',
    '#1b2e3d',
    '#305981',
    '#68aed4',
    '#b6e2f3',
    '#a1abae',
    '#76808c',
    '#4f5670',
    '#2b2f4c',
    '#241e45',
    '#3d2966',
    '#864496',
    '#d667a0',
    '#f58e8e',
    '#f06b6b',
    '#a83737',
    '#591414',
    '#1a0404',
    '#462321',
    '#6b291d',
    '#b8471a',
    '#ea7d2a',
    '#ffb732',
    '#ffda45',
    '#fcf760',
    '#8bd155',
    '#3e9f49',
    '#237350',
    '#245756',
    '#1b2e3d',
    '#305981',
    '#68aed4',
    '#b6e2f3',
    '#a1abae',
    '#76808c',
    '#4f5670',
    '#2b2f4c',
    '#241e45',
    '#3d2966',
    '#864496',
    '#d667a0',
    '#f58e8e',
    '#f06b6b',
    '#a83737',
    '#591414',
    '#1a0404',
    '#462321',
    '#6b291d',
    '#b8471a',
    '#ea7d2a',
    '#ffb732',
    '#ffda45',
    '#fcf760',
    '#8bd155',
    '#3e9f49',
    '#237350',
    '#245756',
    '#1b2e3d',
    '#305981',
    '#68aed4',
    '#b6e2f3',
    '#a1abae',
    '#76808c',
    '#4f5670',
    '#2b2f4c',
    '#241e45',
    '#3d2966',
    '#864496',
    '#d667a0',
    '#f58e8e',
    '#f06b6b',
    '#a83737',
    '#591414',
    '#1a0404',
  ];
  chartOption: EChartsOption = {} as EChartsOption;
  allocationData!: AllocationCategoryData[];
  private readonly destroyed$ = new Subject();

  // investments = [
  //   {
  //     name: 'Alternatives',
  //     value: 216589.11,
  //   },
  //   {
  //     name: 'Annuities',
  //     value: 275658.86,
  //   },
  //   {
  //     name: 'Cash',
  //     value: 216589.11,
  //   },
  //   {
  //     name: 'Equities',
  //     value: 689147.16,
  //   },
  //   {
  //     name: 'Fixed Income',
  //     value: 571007.65,
  //   },
  // ];

  investmentSum = '';
  investmentSumString = '';

  constructor(private store: Store<AppState>) { }

  ngOnInit() {
    this.store.select(getAssetAllocation)
    .pipe(takeUntil(this.destroyed$))
    .subscribe((allocationObj: AllocationData) => {
      this.allocationData = this.allocationType == 'managed' ? allocationObj.internalAssets : allocationObj.portfolioAssets;
      this.chartOption = this.generateChartOptions(this.allocationData);
      this.investmentSum = Math.round(
        this.allocationData.reduce((acc, value) => acc + value.value, 0)
      ).toFixed(2);
    });
  }



  generateChartOptions(allocationData: AllocationCategoryData[]): EChartsOption {
    return {
      color: this.colors,
      series: [
        {
          // bottom: '40%',
          // data: this.investments,
          data: allocationData,
          legendHoverLink: true,
          type: 'pie',
          name: 'Investment Allocation',
          radius: [80, 100],
          avoidLabelOverlap: true,
          // selectedMode: 'single',
          label: {
            show: false,
            position: 'center',
            fontSize: '20',
            fontWeight: 'bold',
            formatter: '${c}',
            //formatter: () => {
              // let totalVal = this.investments.reduce((acc, i) => acc + i.value, 0);
              //// let totalVal = allocationData.reduce((acc, i) => acc + i.value, 0);
              //// return ""+Math.fround(totalVal).toFixed(2);
            //}
          },
          labelLine: {
            show: false
          },
          labelLayout: {
            hideOverlap: true,
          },
          emphasis: {
            label: {
              show: true,
              fontSize: '20',
              // fontWeight: 'bold',
              // formatter: '{c}'
            }
          },
          select: {
            label: {
              show: true,
            }
          }
        },
      ],
      // legend: {
      //   left: 0,
      //   bottom: 0,
      //   orient: 'vertical',
      // }
    };
  };
}
