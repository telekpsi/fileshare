import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, combineLatest, takeUntil } from 'rxjs';
import { AccountsCategory } from 'src/app/models/index.models';
import { AccountsService } from 'src/app/services/accounts.service';
import { getAccountCategoryInfo, getAccounts, getUserId } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';

@Component({
  selector: 'app-managed-financials',
  templateUrl: './managed-financials.component.html',
  styleUrls: ['./managed-financials.component.scss'],
})
export class ManagedFinancialsComponent  implements OnInit {
  private destroy$ = new Subject();
  private readonly destroyed$ = new Subject();

  accordion: AccountsCategory = {
    accountCategory: 'Investment',
    totalAccountsValue: 0,
    status: false,
    accounts: [],
  } 

  constructor(private store: Store<AppState>) { }

  ngOnInit() {
    this.store.select(getUserId).subscribe((x) => {
      if (x == '000') {
        this.accordion.accounts = [];
      } else {
        combineLatest([this.store.select(getAccountCategoryInfo('Investment')),this.store.select(getAccounts)])
          .pipe(takeUntil(this.destroyed$)).subscribe( ([accountCategoryInfo,accounts]) => {
            let info = accountCategoryInfo.filter(aInfo => (aInfo.accountCategory == this.accordion.accountCategory));
            this.accordion = info.length > 0 ? info[0] : this.accordion;
        });
      }
    });
  }
}
