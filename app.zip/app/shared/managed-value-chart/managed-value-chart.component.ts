import { CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppState } from '@capacitor/app';
import { Store } from '@ngrx/store';
import { EChartsOption } from 'echarts';
import { Subject, takeUntil, combineLatest } from 'rxjs';
import { DateTimeSeries } from 'src/app/models/index.models';
import { getNetWorthData } from 'src/app/store/app-selectors';
import { Darkmode } from 'src/app/store/settings-selectors';

@Component({
  selector: 'app-managed-value-chart',
  templateUrl: './managed-value-chart.component.html',
  styleUrls: ['./managed-value-chart.component.scss'],
})
export class ManagedValueChartComponent  implements OnInit {
  private readonly destroyed$ = new Subject();
  chartOptions: EChartsOption = {} as EChartsOption;
  filter: {value: string, date: number} = {value: '1Y', date: 0};
  darkmode: boolean = false;
  managed?: DateTimeSeries;

  constructor(private store: Store<AppState>, private currencyPipe: CurrencyPipe) { }

  ngOnInit() {
    combineLatest([
      this.store.select(Darkmode),
      this.store.select(getNetWorthData),
    ]).pipe(takeUntil(this.destroyed$)).subscribe( ([darkmode, networth]) => {
      this.darkmode = !darkmode;
      this.managed = networth.find(series => series.name === 'Internal');
      this.generateChartOptions();
    });
  }

  segmentChanged(event: any) {
    switch(event.detail.value) {
      case '3M': {
        this.filter = {
          value: event.detail.value,
          date: new Date().setMonth(new Date().getMonth() - 3)/1000,
        }
        break;
      }
      case '1Y': {
        this.filter = {
          value: event.detail.value,
          date: new Date().setFullYear(new Date().getFullYear() - 1)/1000,
        }
        break;
      }
      case '2Y': {
        this.filter = {
          value: event.detail.value,
          date: new Date().setFullYear(new Date().getFullYear() - 2)/1000,
        }
        break;
      }
      default: {
        this.filter = {
          value: 'All',
          date: 0,
        }
      }
    };
    this.generateChartOptions();
  }

  generateChartOptions() {
    const now = new Date().getTime() / 1000;
    const before = (dateVal: string) => (this.parseISOString(dateVal).getTime()/1000 <= now);
    const after = (dateVal: string) => (this.parseISOString(dateVal).getTime()/1000 >= this.filter.date);

    const data: (number|string)[][] = [];
    this.managed?.data.filter(d => before(d.date) && after(d.date)).map(d => [d.date, d.value]).forEach(d => data.push(d));

    const series = {
      name: this.managed?.name,
      type: 'line',
      stack: 'Total',
      smooth: true,
      lineStyle: {width: 2},
      showSymbol: false,
      data: data,
    };
    
    this.chartOptions = {
      color: this.darkmode ? ['#8b16db','#6d1da3','#461a63','#291338'] : ['#74e924','#92e25c','#b9e59c','#d6ecc7'],
      tooltip: {
        valueFormatter: (value) => this.currencyPipe.transform(value as number) || '',
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: this.darkmode ? '#95867a' : '#6a7985',
          }
        }
      },
      legend: {
        show: false,
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '15%',
        containLabel: false
      },
      xAxis: [{
          type: 'time',
          boundaryGap: false,
          show: false,
      }],
      yAxis: [{
        type: 'value',
        show: false,
      }],
      series: [series as echarts.SeriesOption]
    };
  }

  parseISOString(s: string) {
    let b: string[] = s.split(/\D+/);
    return new Date(Date.UTC(+b[0], (+b[1]-1), +b[2], +b[3], +b[4], +b[5], +b[6]));
  }

}
