import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { EChartsOption } from 'echarts';
import * as echarts from 'echarts/types/dist/echarts';
import { Subject, takeUntil, combineLatest } from 'rxjs';
import { AppState } from 'src/app/store/app-store';
import { getNetWorthData, getUserId } from 'src/app/store/app-selectors';
import { DateTimeData, DateTimeSeries } from 'src/app/models/index.models';
import { CurrencyPipe } from '@angular/common';
import { Darkmode } from 'src/app/store/settings-selectors';

@Component({
  selector: 'app-net-worth-chart',
  templateUrl: './net-worth-chart.component.html',
  styleUrls: ['./net-worth-chart.component.scss'],
})
export class NetWorthChartComponent  implements OnInit {
  private readonly destroyed$ = new Subject();
  chartOptions: EChartsOption = {} as EChartsOption;
  exists: boolean = false;
  segmentValue: string = '1Y';
  isDarkMode: boolean = false;
  netWorth: DateTimeSeries[] = [{
      name: 'Investments',
      data: []
    },
    {
      name: 'Authorized',
      data: []
    },
    {
      name: 'Linked',
      data: []
    },
    {
      name: 'Manual',
      data: []
    },
  ]

  constructor(private currencyPipe: CurrencyPipe, private store: Store<AppState>) { }
  // need to figure out get them colors.  blue = "#483748";
  ngOnInit() {
    this.store.select(getUserId).pipe(takeUntil(this.destroyed$)).subscribe( (user: string) => {
      combineLatest(
        [this.store.select(Darkmode),
        this.store.select(getNetWorthData)]
      ).pipe(takeUntil(this.destroyed$)).subscribe( ([darkmode, networth]) => {
        this.netWorth = networth;
        this.isDarkMode = !darkmode;
        this.exists = (user==='000') ? false : networth.reduce((nw,series) => series.data.length > 0 || nw, false);
        this.chartOptions = this.generateChartOptions(this.netWorth);
      });
    });


    // this.store.select(Darkmode).pipe(takeUntil(this.destroyed$)).subscribe((darkmode) => {
    //   this.isDarkMode = darkmode;
    //   // this.chartOptions = this.generateChartOptions(this.netWorth);
    // });
    // this.store.select(getUserId).pipe(takeUntil(this.destroyed$)).subscribe((x) => {
    //   if (x == '000') {
    //     this.exists = false
    //   } else {
    //     this.accountsService.getNetWorth('clientId').pipe(takeUntil(this.destroyed$),
    //     ).subscribe( netWorthData => {
    //       this.netWorth = netWorthData;
    //       this.chartOptions = this.generateChartOptions(netWorthData);
    //     });
    //   }})
  }

  generateChartOptions(data: DateTimeSeries[]): EChartsOption {
    return {
      // change colors based off if store has darkmode on
        color: this.isDarkMode ? ['#8b16db','#6d1da3','#461a63','#291338'] : ['#74e924','#92e25c','#b9e59c','#d6ecc7'] ,
        // title: {text: 'Total Net Worth'},
        tooltip: {
          valueFormatter: (value) => this.currencyPipe.transform(value as number) || '',
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: this.isDarkMode ? '#95867a' : '#6a7985',
            }
          }
        },
        legend: {
          icon: 'none',
          show: true,
          top: 'bottom',
          textStyle: {
            borderWidth: 2,
            borderType: 'solid',
            borderColor: !this.isDarkMode ? '#abc878' : '#543787',
            padding: 3,
            borderRadius: 5,
            color: !this.isDarkMode ? '#abc878' : '#543787',
          },
          padding: 2,
        },
        // toolbox: {},
        grid: {
          left: '3%',
          right: '4%',
          bottom: '15%',
          containLabel: false
        },
        xAxis: [{
            type: 'time',
            boundaryGap: false,
            show: false,
        }],
        yAxis: [{
          type: 'value',
          show: false,
        }],
        series: [
          ...data.map(series => { return {
            name: series.name,
            type: 'line',
            stack: 'Total',
            smooth: true,
            lineStyle: {width: 0},
            showSymbol: false,
            areaStyle: {},
            // emphasis: {focus: 'series'},
            data: series.data.map(d => [d.date, d.value]),
          } as echarts.SeriesOption
        }),
        ]
      };
  };

  segmentChanged(event: any) {
    this.segmentValue = event.detail.value;
    switch(event.detail.value) {
      case '3M': {
        this.on3M();
        break;
      }
      case '1Y': {
        this.on1Y();
        break;
      }
      case '2Y': {
        this.on2Y();
        break;
      }
      case 'All': {
        this.onAll();
        break;
      }
      default: {
        this.on1Y();
        break;
      }
    }
  }

  on3M() {
    const fromTime = new Date().setMonth(new Date().getMonth() - 3)/1000;
    const currentTime = new Date().getTime() / 1000;
    let tempNetWorth: DateTimeSeries[] = [...this.netWorth];
    tempNetWorth = tempNetWorth.map((series: DateTimeSeries) => {
      return {...series, data: series.data.filter((set: DateTimeData) => ((new Date(this.parseISOString(set.date)).getTime() / 1000) <= currentTime) && (new Date(this.parseISOString(set.date)).getTime() / 1000) >= fromTime)};
    })

    this.chartOptions = this.generateChartOptions(tempNetWorth);
  }

  on1Y() {
    const fromTime = new Date().setFullYear(new Date().getFullYear() - 1)/1000;
    const currentTime = new Date().getTime() / 1000;
    let tempNetWorth: DateTimeSeries[] = [...this.netWorth];
    tempNetWorth = tempNetWorth.map((series: DateTimeSeries) => {
      return {...series, data: series.data.filter((set: DateTimeData) => ((new Date(this.parseISOString(set.date)).getTime() / 1000) <= currentTime) && (new Date(this.parseISOString(set.date)).getTime() / 1000) >= fromTime)};
    })
    this.chartOptions = this.generateChartOptions(tempNetWorth);
  }

  on2Y() {
    const fromTime = new Date().setFullYear(new Date().getFullYear() - 2)/1000;
    const currentTime = new Date().getTime() / 1000;
    let tempNetWorth: DateTimeSeries[] = [...this.netWorth];
    tempNetWorth = tempNetWorth.map((series: DateTimeSeries) => {
      return {...series, data: series.data.filter((set: DateTimeData) => ((new Date(this.parseISOString(set.date)).getTime() / 1000) <= currentTime) && (new Date(this.parseISOString(set.date)).getTime() / 1000) >= fromTime)};
    })
    this.chartOptions = this.generateChartOptions(tempNetWorth);
  }

  onAll() {
    this.chartOptions = this.generateChartOptions(this.netWorth);
  }

  addMonths(date: Date, months: number) {
    var d = date.getDate();
    date.setMonth(date.getMonth() + +months);
    if (date.getDate() != d) {
      date.setDate(0);
    }
    return date;
  }

  parseISOString(s: string) {
    let b: string[] = s.split(/\D+/);
    return new Date(Date.UTC(+b[0], (+b[1]-1), +b[2], +b[3], +b[4], +b[5], +b[6]));
  }

  getThemeColours() {
    let colours = ['--ion-color-primary','--ion-color-secondary','--ion-color-primary-shade','--ion-color-secondary-shade','--ion-color-primary-tint','--ion-color-secondary-tint',];
    colours.map(c => getComputedStyle(document.documentElement).getPropertyValue(c));
    return [];
  }

}