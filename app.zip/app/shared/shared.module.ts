import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { HighchartsChartModule } from 'highcharts-angular';
import { NgxEchartsModule } from 'ngx-echarts';
import { Masker, PhoneNumber, PhoneMasker, Truncator } from '../models/pipes/common-pipes';
import { AppMenuComponent } from './app-menu/app-menu.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { InvestmentChartComponent } from './investment-chart/investment-chart.component';
import { NetWorthChartComponent } from './net-worth-chart/net-worth-chart.component';
import { ManagedFinancialsComponent } from './managed-financials/managed-financials.component';
import { AccountAccordionComponent } from './account-accordion/account-accordion.component';
import { AccountCardComponent } from './account-card/account-card.component';
import { HeaderBarComponent } from './header-bar/header-bar.component';
import { ManagedValueChartComponent } from './managed-value-chart/managed-value-chart.component';
import { ErrorBannerComponent } from './error-banner/error-banner.component';
import { ActionsPulloutMenuComponent } from './actions-pullout-menu/actions-pullout-menu.component';
import { GestureDirective } from './gestures/press.gesture';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HighchartsChartModule,
    NgxEchartsModule.forRoot({
      echarts: () => import('echarts')
    })
  ],
  declarations: [
    PhoneNumber,
    HeaderBarComponent,
    Masker,
    PhoneMasker,
    Truncator,
    AppMenuComponent,
    UserMenuComponent,
    InvestmentChartComponent,
    NetWorthChartComponent,
    ManagedFinancialsComponent,
    AccountAccordionComponent,
    AccountCardComponent,
    ManagedValueChartComponent,
    ErrorBannerComponent,
    ActionsPulloutMenuComponent,
    GestureDirective,
  ],
  exports: [
    PhoneNumber,
    HeaderBarComponent,
    Masker,
    PhoneMasker,
    Truncator,
    AppMenuComponent,
    InvestmentChartComponent,
    NetWorthChartComponent,
    ManagedFinancialsComponent,
    AccountAccordionComponent,
    AccountCardComponent,
    ManagedValueChartComponent,
    ErrorBannerComponent,
    ActionsPulloutMenuComponent,
    GestureDirective,
  ],
  providers: [
    CurrencyPipe,
  ]
})
export class SharedModule { }
