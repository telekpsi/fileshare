import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Client } from 'src/app/models/index.models';
import { ModalService } from 'src/app/services/modal.service';
import { getClient, getLastLogin } from 'src/app/store/app-selectors';
import { AppState } from 'src/app/store/app-store';

@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss'],
})
export class UserMenuComponent  implements OnInit {
  client$: Observable<Client>;
  lastLogin$: Observable<string>;

  constructor(private store: Store<AppState>, private modalService: ModalService) {
    this.client$ = this.store.select(getClient);
    this.lastLogin$ = this.store.select(getLastLogin);
  }

  ngOnInit() {}

  onCloseModal() {
    this.modalService.menu='none';
    this.modalService.toggleMenu();
  }
}
