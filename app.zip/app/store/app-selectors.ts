import { createFeatureSelector, createSelector } from "@ngrx/store";
import { AppState } from "./app-store";
import { AccountsCategory, accountCategory } from "../models/account.model";

const getState = createFeatureSelector<AppState>('app');

export const getAuthToken = createSelector(
  getState,
  (state) => { return state.authentication.success?.authToken || '' }
);
export const isLoggedIn = createSelector(
  getState,
  (state) => { return !!state.authentication.success }
);
export const getUserId = createSelector(
  getState,
  (state) => { return state.authentication.success?.userId || '' }
);
export const getAuthProfile = createSelector(
  getState,
  (state) => { return state.authentication }
);
export const getLastLogin = createSelector(
  getState,
  (state) => { return state.lastLogin }
)
export const getAdvisors = createSelector(
  getState,
  (state) => { return state.advisors }
);
export const getClient = createSelector(
  getState,
  (state) => { return state.client }
);
export const getAccounts = createSelector(
  getState,
  (state) => { return state.accounts }
);
export const getAllAccountCategoryInfo = createSelector(
  getState,
  (state) => { return state.accountCategoryInfo }
);
export const getAccountCategoryInfo = (category: accountCategory) => createSelector(
  getState,
  (state) => { return state.accountCategoryInfo.filter( (cat: AccountsCategory) => cat.accountCategory === category) }
);
export const getNetWorthData = createSelector(
  getState,
  (state) => { return state.netWorth }
);
export const getNetWorthHighlights = createSelector(
  getState,
  (state) => { return state.netWorthHighlights }
);
// export const getEnteredToken = createSelector(
//   getState,
//   (state) => { return state.token }
// );
export const getAssetAllocation = createSelector(
  getState,
  (state) => { return state.allocationData }
);

/*
{
      accountCategory: 'Asset',
      accounts: [],
      totalAccountsValue: 0,
    },
*/