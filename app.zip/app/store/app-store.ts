import { createAction, createReducer, on, props } from "@ngrx/store"
import { Advisor, AllocationData, Client, Account, DateTimeSeries, AuthenticationProfile, NetWorthHighlights } from "../models/index.models";
import { AccountsCategory } from "../models/account.model";

// authentication
export const UserLoggedIn = createAction("[App/Auth] User Logged In", props<{ signin: { email: string, passwordhash: string, token: string } }>());
export const SetEnteredToken = createAction("[App/Auth] Set Entered Token", props<{ token: string }>());
export const SetLastLogin = createAction("[App/Auth] Set Last Login", props<{ lastLogin: string }>());
export const OpenedAuthentication = createAction("[App/Auth] Request Authentication", props<{ auth: AuthenticationProfile }>());
export const AuthenticatedUser = createAction("[App/Auth] Authenticated User", props<{ authToken: string, userId: string }>());
export const UserLoggedOut = createAction("[App/Auth] User Logged Out");

// common
export const LoadedAdvisorInfo = createAction("[App/Common] Loaded Advisor Information", props<{ advisor: Advisor }>());
export const LoadedUserInfo = createAction("[App/Common] Loaded User Information", props<{ client: Client }>());
export const SetAdvisorPrimary = createAction("[App/Common] Set Advisor to Primary", props<{ advisorId: number }>());
export const LoadedAccounts = createAction("[App/Common] Loaded Accounts", props<{ accounts: Account[] }>());
export const LoadedAccountCategoryInfo = createAction("[App/Common] Loaded Account Category Info", props<{ accountCategoryInfo: AccountsCategory }>());
export const LoadedNetWorthData = createAction("[App/Common] Loaded Net Worth Data", props<{ data: DateTimeSeries[] }>());
export const LoadedNetWorthHighlights = createAction("[App/Common] Loaded Net Worth Highlights", props<{ netWorthHighlights: NetWorthHighlights }>());
export const LoadedAllocationData = createAction("[App/Common] Loaded Allocation Data", props<{ allocationData: AllocationData }>());

export type AppState = {
    authentication: AuthenticationProfile,
    advisors: Advisor[],
    client: Client,
    lastLogin: string,
    accounts: Account[],
    accountCategoryInfo: AccountsCategory[],
    netWorth: DateTimeSeries[],
    netWorthHighlights: NetWorthHighlights,
    token: string,
    allocationData: AllocationData,
}
const initialState: AppState = {
    authentication: {} as AuthenticationProfile,
    advisors: [],
    client: {} as Client,
    lastLogin: '',
    accounts: [],
    accountCategoryInfo: [],
    netWorth: [],
    netWorthHighlights: {} as NetWorthHighlights,
    token: '',
    allocationData: {} as AllocationData,
}

export const appStateReducer = createReducer(
    initialState,
    on(UserLoggedOut, (state) => { return { ...initialState } }),
    on(SetEnteredToken, (state, {token}) => { return {...state, token: token} }),
    on(SetLastLogin, (state, {lastLogin}) => { return { ...state, lastLogin: lastLogin}}),
    // common
    on(LoadedUserInfo, (state, { client }) => { return { ...state, client: client } }),
    on(LoadedAccounts, (state, { accounts }) => { return { ...state, accounts: [...state.accounts, ...accounts]} }),
    on(LoadedAccountCategoryInfo, (state, { accountCategoryInfo }) => { return { ...state, accountCategoryInfo: [...state.accountCategoryInfo, accountCategoryInfo]} }),
    on(LoadedAdvisorInfo, (state, { advisor }) => {
        let advisors = [...state.advisors, advisor];
        advisors.sort((a, b) => a.isPrimary ? (b.isPrimary ? 0 : -1) : 1);
        return { ...state, advisors: advisors };
    }),
    on(SetAdvisorPrimary, (state, { advisorId }) => {
        let advisors: Advisor[] = [
            ...state.advisors.map(advisor => {return {...advisor, isPrimary: (advisor.advisorId == advisorId)}})
        ];
        advisors.sort((a, b) => a.isPrimary ? (b.isPrimary ? 0 : -1) : 1);
        return { ...state, advisors: advisors };
    }),
    // authentication
    on(OpenedAuthentication, (state, { auth }) => { return { ...state, authentication: auth } }),
    on(AuthenticatedUser, (state, success) => { return { ...state, authentication: {...state.authentication, success: success} }}),
    on(LoadedNetWorthData, (state, {data}) => {return { ...state, netWorth: data };
    }),
    on(LoadedNetWorthHighlights, (state, {netWorthHighlights}) => {return { ...state, netWorthHighlights: netWorthHighlights}}),
    on(LoadedAllocationData, (state, {allocationData}) => {return { ...state, allocationData: allocationData}}),
)