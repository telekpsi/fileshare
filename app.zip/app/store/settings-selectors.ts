import { createFeatureSelector, createSelector } from "@ngrx/store";
import { SettingsState } from "./settings-store";

const getState = createFeatureSelector<SettingsState>('settings');

export const Darkmode = createSelector(
    getState,
    (state) => { return state.darkmode.mode === 'device' ? state.darkmode.device : (state.darkmode.mode == 'on' ? true : false) }
);

export const getDarkmodeSetting = createSelector(
  getState,
  (state) => { return state.darkmode }
);

export const LoginPrefill = createSelector(
  getState,
  (state) => { return state.saveCredentials }
);