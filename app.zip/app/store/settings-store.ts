import { createAction, createReducer, on, props } from "@ngrx/store"

// settings
export const InitializedAppData = createAction("[App/Settings] Initialized App Data");
// settings/darkmode
export const setDeviceDarkmode = createAction("[App/Settings] Sync Darkmode from Device", props<{ darkmode: boolean }>());
export const loadedDarkmode = createAction("[App/Settings] User Toggled Darkmode", props<{ darkmode: DarkmodeOpts }>());
// cred
export const willSaveCredentials = createAction("[App/Settings] Will Save Credentials", props<{ saveCredentials: boolean }>());
export const loadedSavedCredentials = createAction("[App/Settings] Loaded Saved Credentials", props<{ username: string, password: string }>());

export type DarkmodeOpts = 'device' | 'on' | 'off';
export type DarkmodeSetting = {
    mode: DarkmodeOpts,
    device: boolean
};
export type SaveCredentialsSetting = {
    saveCredentials: boolean,
    username?: string,
    password?: string,
};
export type SettingsState = {
    darkmode: DarkmodeSetting,
    saveCredentials: SaveCredentialsSetting,
}
const initialState: SettingsState = {
    darkmode: {
        mode: 'device',
        device: false,
    },
    saveCredentials: {
        saveCredentials: false
    },
}

export const settingsStateReducer = createReducer(
    initialState,
    // darkmode
    on(loadedDarkmode, (state, { darkmode }) => { return { ...state, darkmode: { ...state.darkmode, mode: darkmode } } }),
    on(setDeviceDarkmode, (state, { darkmode }) => { 
        return { ...state, darkmode: { ...state.darkmode, device: darkmode } } 
    }),
    on(willSaveCredentials, (state, { saveCredentials }) => { return { ...state, saveCredentials: { ...state.saveCredentials, saveCredentials } } }),
    on(loadedSavedCredentials, (state, { username, password }) => { return { ...state, saveCredentials: { ...state.saveCredentials, username, password } } }),
);